#include "esp_check.h"
#include "freertos/FreeRTOS.h"
#include "audio_io.h"

#include "driver/i2s_std.h"
#include "esp_log.h"
#include <stdlib.h>

#define MIC_BCLK GPIO_NUM_12
#define MIC_WS   GPIO_NUM_13
#define MIC_DIN  GPIO_NUM_14

static const char *TAG = "MIC";
static i2s_chan_handle_t rx_handle = NULL;

esp_err_t audio_io_init(void)
{
    i2s_chan_config_t chan_config =
        I2S_CHANNEL_DEFAULT_CONFIG(
            I2S_NUM_0,
            I2S_ROLE_MASTER
        );

    ESP_RETURN_ON_ERROR(
        i2s_new_channel(
            &chan_config,
            NULL,
            &rx_handle
        ),
        TAG,
        "Create microphone channel failed"
    );

    i2s_std_config_t std_config = {
        .clk_cfg = I2S_STD_CLK_DEFAULT_CONFIG(
            AUDIO_SAMPLE_RATE
        ),

        .slot_cfg = I2S_STD_MSB_SLOT_DEFAULT_CONFIG(
            I2S_DATA_BIT_WIDTH_32BIT,
            I2S_SLOT_MODE_MONO
        ),

        .gpio_cfg = {
            .mclk = I2S_GPIO_UNUSED,
            .bclk = MIC_BCLK,
            .ws = MIC_WS,
            .dout = I2S_GPIO_UNUSED,
            .din = MIC_DIN,
            .invert_flags = {
                .mclk_inv = false,
                .bclk_inv = false,
                .ws_inv = false
            }
        }
    };

    std_config.slot_cfg.slot_mask = I2S_STD_SLOT_LEFT;

    ESP_RETURN_ON_ERROR(
        i2s_channel_init_std_mode(
            rx_handle,
            &std_config
        ),
        TAG,
        "Microphone I2S initialization failed"
    );

    ESP_RETURN_ON_ERROR(
        i2s_channel_enable(rx_handle),
        TAG,
        "Enable microphone I2S failed"
    );

    ESP_LOGI(TAG, "INMP441 ready");

    return ESP_OK;
}

esp_err_t audio_io_read(
    int16_t *buffer,
    size_t samples,
    size_t *samples_read)
{
    if (!buffer || !samples_read || !rx_handle) {
        return ESP_ERR_INVALID_ARG;
    }

    int32_t *raw = malloc(samples * sizeof(int32_t));

    if (!raw) {
        return ESP_ERR_NO_MEM;
    }

    size_t bytes_read = 0;

    esp_err_t err = i2s_channel_read(
        rx_handle,
        raw,
        samples * sizeof(int32_t),
        &bytes_read,
        pdMS_TO_TICKS(100)
    );

    *samples_read = bytes_read / sizeof(int32_t);

    if (err == ESP_OK) {
        for (size_t i = 0; i < *samples_read; i++) {
            /*
             * INMP441: 24-bit audio in 32-bit slot.
             * Adjust shift after checking actual signal level.
             */
            buffer[i] = (int16_t)(raw[i] >> 16);
        }
    }

    free(raw);

    return err;
}

esp_err_t audio_io_deinit(void)
{
    if (rx_handle) {
        i2s_channel_disable(rx_handle);
        i2s_del_channel(rx_handle);
        rx_handle = NULL;
    }

    return ESP_OK;
}

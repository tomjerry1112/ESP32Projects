
#include "speaker.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/i2s_std.h"
#include "esp_log.h"

#include <string.h>
#include <stdlib.h>
#include "esp_check.h"
#define SPK_BCLK GPIO_NUM_15
#define SPK_LRC  GPIO_NUM_16
#define SPK_DOUT GPIO_NUM_17

#define SPK_SAMPLE_RATE 16000

static const char *TAG = "SPEAKER";

static i2s_chan_handle_t tx_handle = NULL;

static uint16_t read_u16(const uint8_t *p)
{
    return p[0] | ((uint16_t)p[1] << 8);
}

static uint32_t read_u32(const uint8_t *p)
{
    return (uint32_t)p[0] |
           ((uint32_t)p[1] << 8) |
           ((uint32_t)p[2] << 16) |
           ((uint32_t)p[3] << 24);
}

esp_err_t speaker_init(void)
{
    i2s_chan_config_t channel_config =
        I2S_CHANNEL_DEFAULT_CONFIG(
            I2S_NUM_1,
            I2S_ROLE_MASTER
        );

    ESP_RETURN_ON_ERROR(
        i2s_new_channel(
            &channel_config,
            &tx_handle,
            NULL
        ),
        TAG,
        "Create speaker channel failed"
    );

    i2s_std_config_t config = {
        .clk_cfg = I2S_STD_CLK_DEFAULT_CONFIG(
            SPK_SAMPLE_RATE
        ),

        .slot_cfg = I2S_STD_PHILIPS_SLOT_DEFAULT_CONFIG(
            I2S_DATA_BIT_WIDTH_16BIT,
            I2S_SLOT_MODE_STEREO
        ),

        .gpio_cfg = {
            .mclk = I2S_GPIO_UNUSED,
            .bclk = SPK_BCLK,
            .ws = SPK_LRC,
            .dout = SPK_DOUT,
            .din = I2S_GPIO_UNUSED,
            .invert_flags = {
                .mclk_inv = false,
                .bclk_inv = false,
                .ws_inv = false
            }
        }
    };

    ESP_RETURN_ON_ERROR(
        i2s_channel_init_std_mode(
            tx_handle,
            &config
        ),
        TAG,
        "Speaker I2S initialization failed"
    );

    ESP_RETURN_ON_ERROR(
        i2s_channel_enable(tx_handle),
        TAG,
        "Speaker I2S enable failed"
    );

    ESP_LOGI(TAG, "MAX98357A ready");

    return ESP_OK;
}

esp_err_t speaker_play_wav(
    const uint8_t *wav,
    size_t wav_size)
{
    if (!wav || !tx_handle || wav_size < 44) {
        return ESP_ERR_INVALID_ARG;
    }

    if (memcmp(wav, "RIFF", 4) ||
        memcmp(wav + 8, "WAVE", 4)) {
        ESP_LOGE(TAG, "Not a WAV file");
        return ESP_ERR_INVALID_ARG;
    }

    uint16_t format = 0;
    uint16_t channels = 0;
    uint16_t bits = 0;
    uint32_t rate = 0;

    const uint8_t *audio = NULL;
    size_t audio_size = 0;

    size_t offset = 12;

    while (offset + 8 <= wav_size) {
        const uint8_t *chunk = wav + offset;
        uint32_t length = read_u32(chunk + 4);

        if (length > wav_size - offset - 8) {
            return ESP_ERR_INVALID_SIZE;
        }

        if (!memcmp(chunk, "fmt ", 4)) {
            if (length < 16) {
                return ESP_ERR_INVALID_SIZE;
            }

            format = read_u16(wav + offset + 8);
            channels = read_u16(wav + offset + 10);
            rate = read_u32(wav + offset + 12);
            bits = read_u16(wav + offset + 22);
        }

        if (!memcmp(chunk, "data", 4)) {
            audio = wav + offset + 8;
            audio_size = length;
            break;
        }

        offset += 8 + length + (length & 1U);
    }

    if (!audio ||
        format != 1 ||
        channels != 1 ||
        bits != 16 ||
        rate != SPK_SAMPLE_RATE ||
        (audio_size & 1U)) {

        ESP_LOGE(TAG,
            "WAV must be PCM mono 16-bit 16000Hz");

        return ESP_ERR_NOT_SUPPORTED;
    }

    const int16_t *samples = (const int16_t *)audio;

    size_t count = audio_size / sizeof(int16_t);

    int16_t stereo[512 * 2];

    size_t position = 0;

    while (position < count) {
        size_t n = count - position;

        if (n > 512) {
            n = 512;
        }

        for (size_t i = 0; i < n; i++) {
            stereo[2 * i] = samples[position + i];
            stereo[2 * i + 1] = samples[position + i];
        }

        size_t written = 0;

        esp_err_t err = i2s_channel_write(
            tx_handle,
            stereo,
            n * 2 * sizeof(int16_t),
            &written,
            portMAX_DELAY
        );

        if (err != ESP_OK) {
            return err;
        }

        position += n;
    }

    return ESP_OK;
}

esp_err_t speaker_deinit(void)
{
    if (tx_handle) {
        i2s_channel_disable(tx_handle);
        i2s_del_channel(tx_handle);
        tx_handle = NULL;
    }

    return ESP_OK;
}

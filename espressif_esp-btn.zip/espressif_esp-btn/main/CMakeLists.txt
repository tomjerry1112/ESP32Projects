
idf_component_register(
    SRCS
        "main.c"
        "audio_io.c"
        "button.c"
        "led_control.c"
        "speaker.c"

    INCLUDE_DIRS
        "."

    REQUIRES
        driver
        esp-sr

    EMBED_FILES
        "Led_on.wav"
        "Led_off.wav"
)

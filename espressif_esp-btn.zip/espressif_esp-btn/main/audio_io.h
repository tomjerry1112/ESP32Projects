
#pragma once

#include <stddef.h>
#include <stdint.h>
#include "esp_err.h"

#define AUDIO_SAMPLE_RATE 16000
#define AUDIO_CHUNK_SIZE  512

esp_err_t audio_io_init(void);

esp_err_t audio_io_read(
    int16_t *buffer,
    size_t samples,
    size_t *samples_read
);

esp_err_t audio_io_deinit(void);

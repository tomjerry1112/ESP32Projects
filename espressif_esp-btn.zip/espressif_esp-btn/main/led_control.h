
#pragma once

#include "esp_err.h"
#include <stdbool.h>

typedef enum {
    DEVICE_RECORDER = 0,
    DEVICE_LIGHT,
    DEVICE_WINDOW
} led_device_t;

esp_err_t led_control_init(void);

void led_control_set(
    led_device_t device,
    bool enabled
);

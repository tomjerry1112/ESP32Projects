
#pragma once

#include "esp_err.h"
#include <stddef.h>
#include <stdint.h>

esp_err_t speaker_init(void);

esp_err_t speaker_play_wav(
    const uint8_t *wav_data,
    size_t wav_size
);

esp_err_t speaker_deinit(void);

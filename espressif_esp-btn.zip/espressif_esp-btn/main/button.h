
#pragma once

#include "esp_err.h"
#include <stdbool.h>

esp_err_t button_init(void);
bool button_is_pressed(void);
void button_wait_for_press(void);
void button_wait_for_release(void);

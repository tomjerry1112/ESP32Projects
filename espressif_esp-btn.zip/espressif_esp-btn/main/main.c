
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "esp_log.h"
#include "esp_err.h"
#include "esp_heap_caps.h"

#include "esp_mn_iface.h"
#include "esp_mn_models.h"
#include "esp_process_sdkconfig.h"
#include "model_path.h"

#include "audio_io.h"
#include "button.h"
#include "led_control.h"
#include "speaker.h"

#define TAG "VOICE_CONTROL"

#define RECORD_SECONDS 4
#define MAX_RECORD_SAMPLES \
    (AUDIO_SAMPLE_RATE * RECORD_SECONDS)

#define COMMAND_RECORDER_ON  0
#define COMMAND_RECORDER_OFF 1
#define COMMAND_LIGHT_ON     2
#define COMMAND_LIGHT_OFF    3
#define COMMAND_WINDOW_ON    4
#define COMMAND_WINDOW_OFF   5

extern const uint8_t _binary_Led_on_wav_start[];
extern const uint8_t _binary_Led_on_wav_end[];

extern const uint8_t _binary_Led_off_wav_start[];
extern const uint8_t _binary_Led_off_wav_end[];

static srmodel_list_t *models = NULL;
static esp_mn_iface_t *multinet = NULL;
static model_iface_data_t *model_data = NULL;

static int16_t *record_buffer = NULL;
static size_t record_samples = 0;

static void play_on_sound(void)
{
    size_t size =
        _binary_Led_on_wav_end -
        _binary_Led_on_wav_start;

    ESP_ERROR_CHECK(
        speaker_play_wav(
            _binary_Led_on_wav_start,
            size
        )
    );
}

static void play_off_sound(void)
{
    size_t size =
        _binary_Led_off_wav_end -
        _binary_Led_off_wav_start;

    ESP_ERROR_CHECK(
        speaker_play_wav(
            _binary_Led_off_wav_start,
            size
        )
    );
}

static void execute_command(int command_id)
{
    ESP_LOGI(TAG, "Executing command ID: %d", command_id);

    switch (command_id) {

        case COMMAND_RECORDER_ON:
            led_control_set(DEVICE_RECORDER, true);
            play_on_sound();
            break;

        case COMMAND_RECORDER_OFF:
            led_control_set(DEVICE_RECORDER, false);
            play_off_sound();
            break;

        case COMMAND_LIGHT_ON:
            led_control_set(DEVICE_LIGHT, true);
            play_on_sound();
            break;

        case COMMAND_LIGHT_OFF:
            led_control_set(DEVICE_LIGHT, false);
            play_off_sound();
            break;

        case COMMAND_WINDOW_ON:
            led_control_set(DEVICE_WINDOW, true);
            play_on_sound();
            break;

        case COMMAND_WINDOW_OFF:
            led_control_set(DEVICE_WINDOW, false);
            play_off_sound();
            break;

        default:
            ESP_LOGW(TAG, "Unknown command ID: %d", command_id);
            break;
    }
}

static void recognize_command(void)
{
    if (record_samples < AUDIO_SAMPLE_RATE / 4) {
        ESP_LOGW(TAG, "Recording too short");
        return;
    }

    int chunk_size =
        multinet->get_samp_chunksize(model_data);

    if (chunk_size <= 0) {
        ESP_LOGE(TAG, "Invalid MultiNet chunk size");
        return;
    }

    ESP_LOGI(TAG, "Recognition started: %u samples",
             (unsigned)record_samples);

    multinet->clean(model_data);

    bool found = false;

    for (size_t pos = 0;
         pos + chunk_size <= record_samples;
         pos += chunk_size) {

        esp_mn_state_t state =
            multinet->detect(
                model_data,
                record_buffer + pos
            );

        if (state == ESP_MN_STATE_DETECTED) {

            esp_mn_results_t *result =
                multinet->get_results(model_data);

            if (result && result->num > 0) {

                ESP_LOGI(
                    TAG,
                    "Recognized: %s",
                    result->string
                );

                ESP_LOGI(
                    TAG,
                    "Command ID: %d",
                    result->command_id[0]
                );

                ESP_LOGI(
                    TAG,
                    "Probability: %f",
                    result->prob[0]
                );

                execute_command(result->command_id[0]);

                found = true;
            }

            break;
        }

        if (state == ESP_MN_STATE_TIMEOUT) {
            ESP_LOGW(TAG, "Recognition timeout");
            break;
        }
    }

    if (!found) {
        ESP_LOGW(TAG, "No command recognized");
    }

    record_samples = 0;
}

static void record_while_button_pressed(void)
{
    record_samples = 0;

    int16_t audio_chunk[AUDIO_CHUNK_SIZE];

    ESP_LOGI(TAG, "Recording... Speak your command");

    while (button_is_pressed()) {

        size_t received = 0;

        esp_err_t err = audio_io_read(
            audio_chunk,
            AUDIO_CHUNK_SIZE,
            &received
        );

        if (err != ESP_OK) {
            if (err != ESP_ERR_TIMEOUT) {
                ESP_LOGW(TAG, "Microphone read error: %s",
                         esp_err_to_name(err));
            }
            continue;
        }

        if (received == 0) {
            continue;
        }

        size_t remaining =
            MAX_RECORD_SAMPLES - record_samples;

        size_t copy_count = received;

        if (copy_count > remaining) {
            copy_count = remaining;
        }

        if (copy_count > 0) {
            memcpy(
                record_buffer + record_samples,
                audio_chunk,
                copy_count * sizeof(int16_t)
            );

            record_samples += copy_count;
        }

        if (record_samples >= MAX_RECORD_SAMPLES) {
            ESP_LOGW(TAG, "Maximum recording time reached");
            break;
        }
    }

    ESP_LOGI(TAG, "Recording finished");
}

static void initialize_multinet(void)
{
    models = esp_srmodel_init("model");

    if (!models) {
        ESP_LOGE(TAG, "Cannot load model partition");
        abort();
    }

    char *model_name = esp_srmodel_filter(
        models,
        ESP_MN_PREFIX,
        ESP_MN_CHINESE
    );

    if (!model_name) {
        ESP_LOGE(TAG, "Chinese MultiNet model not found");
        abort();
    }

    ESP_LOGI(TAG, "Loading MultiNet: %s", model_name);

    multinet = esp_mn_handle_from_name(model_name);

    if (!multinet) {
        ESP_LOGE(TAG, "Cannot obtain MultiNet interface");
        abort();
    }

    model_data = multinet->create(model_name, 6000);

    if (!model_data) {
        ESP_LOGE(TAG, "Cannot create MultiNet model");
        abort();
    }

    /*
     * Load the six commands from the existing ESP-SR
     * menuconfig command configuration.
     */
esp_mn_error_t *command_error =
    esp_mn_commands_update_from_sdkconfig(
        multinet,
        model_data
    );

if (command_error != NULL) {
    ESP_LOGE(TAG, "MultiNet command configuration failed");
    abort();
}

    multinet->print_active_speech_commands(model_data);

    ESP_LOGI(TAG, "MultiNet initialized");
}

void app_main(void)
{
    ESP_LOGI(TAG, "ESP32-S3 Chinese Voice Controller");

    ESP_ERROR_CHECK(button_init());

    ESP_ERROR_CHECK(led_control_init());

    ESP_ERROR_CHECK(audio_io_init());

    ESP_ERROR_CHECK(speaker_init());

    record_buffer = heap_caps_malloc(
        MAX_RECORD_SAMPLES * sizeof(int16_t),
        MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT
    );

    if (!record_buffer) {
        record_buffer = heap_caps_malloc(
            MAX_RECORD_SAMPLES * sizeof(int16_t),
            MALLOC_CAP_8BIT
        );
    }

    if (!record_buffer) {
        ESP_LOGE(TAG, "Recording memory allocation failed");
        abort();
    }

    initialize_multinet();

    ESP_LOGI(TAG, "================================");
    ESP_LOGI(TAG, "WakeWord: DISABLED");
    ESP_LOGI(TAG, "Push-to-talk: ENABLED");
    ESP_LOGI(TAG, "Chinese MultiNet: ENABLED");
    ESP_LOGI(TAG, "================================");

    while (1) {

        button_wait_for_press();

        record_while_button_pressed();

        button_wait_for_release();

        recognize_command();

        ESP_LOGI(TAG, "Ready for next command");

        vTaskDelay(pdMS_TO_TICKS(100));
    }
}

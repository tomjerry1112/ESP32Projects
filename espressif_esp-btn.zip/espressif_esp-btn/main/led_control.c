
#include "led_control.h"

#include "driver/gpio.h"

#define LED_RECORDER GPIO_NUM_5
#define LED_LIGHT    GPIO_NUM_6
#define LED_WINDOW   GPIO_NUM_7

esp_err_t led_control_init(void)
{
    gpio_config_t config = {
        .pin_bit_mask =
            (1ULL << LED_RECORDER) |
            (1ULL << LED_LIGHT) |
            (1ULL << LED_WINDOW),

        .mode = GPIO_MODE_OUTPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE
    };

    esp_err_t err = gpio_config(&config);

    if (err != ESP_OK) {
        return err;
    }

    gpio_set_level(LED_RECORDER, 0);
    gpio_set_level(LED_LIGHT, 0);
    gpio_set_level(LED_WINDOW, 0);

    return ESP_OK;
}

void led_control_set(
    led_device_t device,
    bool enabled)
{
    gpio_num_t pin;

    switch (device) {
        case DEVICE_RECORDER:
            pin = LED_RECORDER;
            break;

        case DEVICE_LIGHT:
            pin = LED_LIGHT;
            break;

        case DEVICE_WINDOW:
            pin = LED_WINDOW;
            break;

        default:
            return;
    }

    gpio_set_level(pin, enabled ? 1 : 0);
}

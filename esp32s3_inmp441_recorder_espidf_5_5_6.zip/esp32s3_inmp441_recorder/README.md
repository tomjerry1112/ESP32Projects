# ESP32-S3 N16R8 + INMP441 20-second WAV recorder

ESP-IDF **5.5.6**, Windows 10.

## Function

1. Wait for a button press.
2. Wait until the button is released.
3. Record exactly 20 seconds of audio.
4. Save a mono PCM WAV file to the MicroSD card.
5. Turn the status LED off and wait for the next button action.

Output names: `REC0001.WAV`, `REC0002.WAV`, ...

## Audio format

- Sample rate: 16,000 Hz
- WAV encoding: PCM (format tag 1)
- Bit depth: 16-bit
- Channels: 1 (mono)
- Duration: 20 seconds
- Samples: 320,000
- Audio data: 640,000 bytes
- Expected WAV file size: 640,044 bytes

## IMPORTANT: N16R8 GPIO warning

Do not use GPIO26-GPIO32 for ordinary signals. On ESP32-S3 devices with octal PSRAM,
GPIO33-GPIO37 are also connected to the memory interface. The original proposed
INMP441 pins GPIO26, GPIO33 and GPIO32 must therefore be changed.

The included example pin map is:

| Signal | ESP32-S3 GPIO |
|---|---:|
| INMP441 SCK / BCLK | 4 |
| INMP441 WS / LRCLK | 6 |
| INMP441 SD / DOUT | 7 |
| INMP441 L/R | GND |
| INMP441 VDD | 3.3V |
| INMP441 GND | GND |
| MicroSD CS | 5 |
| MicroSD SCK | 12 |
| MicroSD MOSI | 11 |
| MicroSD MISO | 10 |
| MicroSD VCC | 3.3V-compatible supply |
| MicroSD GND | GND |
| LED anode | GPIO13 through 220-1k ohm resistor |
| LED cathode | GND |
| Button terminal 1 | GPIO14 |
| Button terminal 2 | 3.3V |

The button input uses the ESP32-S3 internal pulldown. Do not put a series resistor
between the button and 3.3V. If you prefer an external pulldown, use about 10k ohm
from GPIO14 to GND, with the button between GPIO14 and 3.3V.

All grounds must be common. Use a 3.3V-compatible MicroSD SPI module and logic levels.
Some SD modules contain level shifters and regulators; check the module before powering it.

The SPI pin assignments are examples. Change them in `main/pins.h` if your board
uses different exposed pins. The I2S pins can also be changed there, but keep them
off the flash/PSRAM-reserved pins.

## Configure for ESP-IDF 5.5.6 on Windows 10

Open **ESP-IDF 5.5.6 PowerShell** (or ESP-IDF Command Prompt) from the Espressif
ESP-IDF installation. Do not use a normal PowerShell unless `IDF_PATH` and the
toolchain environment have already been exported.

Change directory to this project:

```powershell
cd path\to\esp32s3_inmp441_recorder
idf.py set-target esp32s3
idf.py fullclean
idf.py build
```

Connect the board by USB, find its COM port in Device Manager, then flash:

```powershell
idf.py -p COMx flash monitor
```

Replace `COMx` with the actual port, for example `COM7`. Exit the monitor with
`Ctrl+]`.

## SD card preparation

Format the card as FAT32 on a PC before first use. The firmware deliberately does
not format a card automatically. Insert the card before powering the board.

## How the audio capture works

The INMP441 sends 24-bit I2S samples in 32-bit slots. The firmware reads stereo
32-bit I2S frames to keep the standard 64-clock I2S frame, selects the LEFT slot
because L/R is tied to GND, and takes the upper 16 bits for 16-bit PCM.

The WAV file header is written first with the exact expected data length. The code
then reads 320,000 left-channel samples and writes 640,000 bytes of PCM data.

## Troubleshooting

- `SD mount failed`: check CS/SCK/MOSI/MISO, common ground, card format, module
  voltage compatibility, and SPI wiring.
- `I2S ... failed`: verify BCLK/WS/DIN wiring and that the board exposes the chosen pins.
- Silent audio: confirm INMP441 VDD=3.3V, L/R=GND, common ground, and correct I2S pins.
- Distorted audio: verify the microphone wiring and test with a different microphone
  module. The 16-bit conversion uses the upper 16 bits of the INMP441's 24-bit sample.
- If the board does not expose GPIO4, 6, 7, 10, 11, or 12, select other free GPIOs
  in `main/pins.h`.

## Project layout

```text
esp32s3_inmp441_recorder/
├── CMakeLists.txt
├── README.md
└── main/
    ├── CMakeLists.txt
    ├── main.c
    └── pins.h
```

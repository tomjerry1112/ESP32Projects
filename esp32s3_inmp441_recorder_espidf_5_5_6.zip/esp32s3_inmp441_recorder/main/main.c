#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <sys/stat.h>
#include <inttypes.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "esp_err.h"
#include "esp_check.h"
#include "esp_log.h"
#include "esp_timer.h"

#include "driver/gpio.h"
#include "driver/i2s_std.h"
#include "driver/spi_common.h"
#include "driver/sdspi_host.h"

#include "sdmmc_cmd.h"
#include "esp_vfs_fat.h"

#include "pins.h"

#define TAG                 "AUDIO_REC"
#define SAMPLE_RATE         16000U
#define RECORD_SECONDS      20U
#define CHANNELS            1U
#define BITS_PER_SAMPLE     16U
#define TOTAL_SAMPLES       (SAMPLE_RATE * RECORD_SECONDS)
#define WAV_DATA_BYTES      (TOTAL_SAMPLES * sizeof(int16_t))
#define SD_MOUNT_POINT      "/sdcard"
#define I2S_READ_TIMEOUT    pdMS_TO_TICKS(1000)
#define BUTTON_DEBOUNCE_MS  30U

static i2s_chan_handle_t s_rx_chan = NULL;
static sdmmc_card_t *s_card = NULL;
static bool s_sd_mounted = false;

/* Write a 16-bit little-endian value to a WAV header. */
static void put_u16_le(uint8_t *p, uint16_t value)
{
    p[0] = (uint8_t)(value & 0xff);
    p[1] = (uint8_t)((value >> 8) & 0xff);
}

/* Write a 32-bit little-endian value to a WAV header. */
static void put_u32_le(uint8_t *p, uint32_t value)
{
    p[0] = (uint8_t)(value & 0xff);
    p[1] = (uint8_t)((value >> 8) & 0xff);
    p[2] = (uint8_t)((value >> 16) & 0xff);
    p[3] = (uint8_t)((value >> 24) & 0xff);
}

static bool write_wav_header(FILE *file, uint32_t data_bytes)
{
    uint8_t h[44] = {0};

    memcpy(&h[0], "RIFF", 4);
    put_u32_le(&h[4], 36U + data_bytes);
    memcpy(&h[8], "WAVE", 4);
    memcpy(&h[12], "fmt ", 4);
    put_u32_le(&h[16], 16U);                 /* PCM fmt chunk size */
    put_u16_le(&h[20], 1U);                  /* PCM format */
    put_u16_le(&h[22], CHANNELS);
    put_u32_le(&h[24], SAMPLE_RATE);
    put_u32_le(&h[28], SAMPLE_RATE * CHANNELS * BITS_PER_SAMPLE / 8U);
    put_u16_le(&h[32], CHANNELS * BITS_PER_SAMPLE / 8U);
    put_u16_le(&h[34], BITS_PER_SAMPLE);
    memcpy(&h[36], "data", 4);
    put_u32_le(&h[40], data_bytes);

    return fwrite(h, 1, sizeof(h), file) == sizeof(h);
}

static esp_err_t init_i2s_microphone(void)
{
    i2s_chan_config_t chan_cfg = I2S_CHANNEL_DEFAULT_CONFIG(I2S_NUM_0, I2S_ROLE_MASTER);
    chan_cfg.dma_desc_num = 8;
    chan_cfg.dma_frame_num = 256;
    chan_cfg.auto_clear = true;

    ESP_RETURN_ON_ERROR(i2s_new_channel(&chan_cfg, NULL, &s_rx_chan),
                        TAG, "Create I2S channel failed");

    /*
     * Read stereo 32-bit slots to preserve the standard 64-BCLK frame
     * expected by the INMP441. L/R is tied to GND, so use the LEFT slot.
     */
    i2s_std_config_t std_cfg = {
        .clk_cfg = I2S_STD_CLK_DEFAULT_CONFIG(SAMPLE_RATE),
        .slot_cfg = I2S_STD_PHILIPS_SLOT_DEFAULT_CONFIG(
            I2S_DATA_BIT_WIDTH_32BIT, I2S_SLOT_MODE_STEREO),
        .gpio_cfg = {
            .mclk = I2S_GPIO_UNUSED,
            .bclk = PIN_I2S_BCLK,
            .ws   = PIN_I2S_WS,
            .dout = I2S_GPIO_UNUSED,
            .din  = PIN_I2S_DIN,
            .invert_flags = {
                .mclk_inv = false,
                .bclk_inv = false,
                .ws_inv = false,
            },
        },
    };
    std_cfg.slot_cfg.slot_mask = I2S_STD_SLOT_BOTH;

    ESP_RETURN_ON_ERROR(i2s_channel_init_std_mode(s_rx_chan, &std_cfg),
                        TAG, "I2S standard-mode init failed");
    ESP_RETURN_ON_ERROR(i2s_channel_enable(s_rx_chan),
                        TAG, "Enable I2S RX failed");

    ESP_LOGI(TAG, "I2S microphone ready: %u Hz, 32-bit slots, left channel",
             (unsigned)SAMPLE_RATE);
    return ESP_OK;
}

static esp_err_t init_sd_card(void)
{
    sdmmc_host_t host = SDSPI_HOST_DEFAULT();
    host.slot = SPI2_HOST;

    spi_bus_config_t bus_cfg = {
        .mosi_io_num = PIN_SD_MOSI,
        .miso_io_num = PIN_SD_MISO,
        .sclk_io_num = PIN_SD_SCK,
        .quadwp_io_num = -1,
        .quadhd_io_num = -1,
        .max_transfer_sz = 4096,
    };

    esp_err_t err = spi_bus_initialize((spi_host_device_t)host.slot,
                                        &bus_cfg, SPI_DMA_CH_AUTO);
    if (err != ESP_OK && err != ESP_ERR_INVALID_STATE) {
        ESP_LOGE(TAG, "SPI bus init failed: %s", esp_err_to_name(err));
        return err;
    }

    sdspi_device_config_t slot_config = SDSPI_DEVICE_CONFIG_DEFAULT();
    slot_config.host_id = (spi_host_device_t)host.slot;
    slot_config.gpio_cs = PIN_SD_CS;

    esp_vfs_fat_mount_config_t mount_cfg = {
        .format_if_mount_failed = false, /* Never format user's card automatically */
        .max_files = 5,
        .allocation_unit_size = 16 * 1024,
    };

    err = esp_vfs_fat_sdspi_mount(SD_MOUNT_POINT, &host, &slot_config,
                                  &mount_cfg, &s_card);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "SD mount failed: %s", esp_err_to_name(err));
        return err;
    }

    s_sd_mounted = true;
    sdmmc_card_print_info(stdout, s_card);
    ESP_LOGI(TAG, "SD card mounted at %s", SD_MOUNT_POINT);
    return ESP_OK;
}

static void init_user_io(void)
{
    gpio_config_t led_cfg = {
        .pin_bit_mask = 1ULL << PIN_STATUS_LED,
        .mode = GPIO_MODE_OUTPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    ESP_ERROR_CHECK(gpio_config(&led_cfg));
    gpio_set_level(PIN_STATUS_LED, 0);

    /*
     * Button wiring: GPIO14 -- momentary button -- 3.3V.
     * Enable internal pulldown so idle=LOW and pressed=HIGH.
     */
    gpio_config_t btn_cfg = {
        .pin_bit_mask = 1ULL << PIN_RECORD_BUTTON,
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_ENABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    ESP_ERROR_CHECK(gpio_config(&btn_cfg));
}

static esp_err_t find_next_filename(char *path, size_t path_size)
{
    struct stat st;

    for (unsigned int n = 1; n <= 9999; ++n) {
        int written = snprintf(path, path_size, SD_MOUNT_POINT "/REC%04u.WAV", n);
        if (written < 0 || (size_t)written >= path_size) {
            return ESP_ERR_INVALID_SIZE;
        }
        if (stat(path, &st) != 0) {
            return ESP_OK;
        }
    }
    return ESP_ERR_NOT_FOUND;
}

static esp_err_t record_one_file(void)
{
    if (!s_sd_mounted || s_rx_chan == NULL) {
        ESP_LOGE(TAG, "Recorder is not initialized");
        return ESP_ERR_INVALID_STATE;
    }

    char filename[64];
    ESP_RETURN_ON_ERROR(find_next_filename(filename, sizeof(filename)),
                        TAG, "Could not allocate recording filename");

    FILE *file = fopen(filename, "wb");
    if (file == NULL) {
        ESP_LOGE(TAG, "Cannot create %s", filename);
        return ESP_FAIL;
    }

    gpio_set_level(PIN_STATUS_LED, 1);
    ESP_LOGI(TAG, "Recording started: %s", filename);

    bool ok = write_wav_header(file, WAV_DATA_BYTES);
    uint32_t samples_written = 0;

    /*
     * INMP441 sends signed 24-bit samples left-aligned in 32-bit slots.
     * Taking bits [31:16] gives signed 16-bit PCM.
     * With L/R connected to GND, the microphone is in the LEFT slot.
     */
    int32_t i2s_words[1024];       /* 512 stereo frames */
    int16_t pcm[512];

    while (ok && samples_written < TOTAL_SAMPLES) {
        size_t bytes_read = 0;
        esp_err_t err = i2s_channel_read(s_rx_chan, i2s_words,
                                         sizeof(i2s_words), &bytes_read,
                                         I2S_READ_TIMEOUT);
        if (err != ESP_OK) {
            ESP_LOGE(TAG, "I2S read failed: %s", esp_err_to_name(err));
            ok = false;
            break;
        }

        size_t frames = bytes_read / (sizeof(int32_t) * 2U);
        if (frames == 0) {
            continue;
        }

        size_t remaining = TOTAL_SAMPLES - samples_written;
        if (frames > remaining) {
            frames = remaining;
        }

        for (size_t i = 0; i < frames; ++i) {
            int32_t sample = i2s_words[i * 2U]; /* LEFT slot */
            pcm[i] = (int16_t)(sample >> 16);
        }

        size_t bytes_to_write = frames * sizeof(int16_t);
        if (fwrite(pcm, 1, bytes_to_write, file) != bytes_to_write) {
            ESP_LOGE(TAG, "SD write error");
            ok = false;
            break;
        }
        samples_written += (uint32_t)frames;
    }

    if (fflush(file) != 0) {
        ESP_LOGE(TAG, "File flush failed");
        ok = false;
    }
    if (fclose(file) != 0) {
        ESP_LOGE(TAG, "File close failed");
        ok = false;
    }

    gpio_set_level(PIN_STATUS_LED, 0);

    if (!ok || samples_written != TOTAL_SAMPLES) {
        remove(filename); /* Do not leave a misleading incomplete WAV file */
        ESP_LOGE(TAG, "Recording failed; incomplete file removed (%" PRIu32
                 "/%u samples)", samples_written, (unsigned)TOTAL_SAMPLES);
        return ESP_FAIL;
    }

    ESP_LOGI(TAG, "Recording saved: %s", filename);
    ESP_LOGI(TAG, "Samples: %" PRIu32 ", audio bytes: %u",
             samples_written, (unsigned)WAV_DATA_BYTES);
    return ESP_OK;
}

void app_main(void)
{
    ESP_LOGI(TAG, "ESP32-S3 INMP441 20-second WAV recorder");
    ESP_LOGI(TAG, "Format: 16 kHz, 16-bit, mono PCM, WAV");

    init_user_io();

    ESP_ERROR_CHECK(init_i2s_microphone());
    ESP_ERROR_CHECK(init_sd_card());

    ESP_LOGI(TAG, "Ready. Press and RELEASE the button to record 20 seconds.");

    bool raw_previous = gpio_get_level(PIN_RECORD_BUTTON);
    bool stable_state = raw_previous;
    bool press_seen = stable_state;
    int64_t last_raw_change_ms = esp_timer_get_time() / 1000;

    while (1) {
        bool raw_now = gpio_get_level(PIN_RECORD_BUTTON);
        int64_t now_ms = esp_timer_get_time() / 1000;

        if (raw_now != raw_previous) {
            raw_previous = raw_now;
            last_raw_change_ms = now_ms;
        }

        if ((now_ms - last_raw_change_ms) >= BUTTON_DEBOUNCE_MS &&
            stable_state != raw_previous) {
            stable_state = raw_previous;

            if (stable_state) {
                /* Stable HIGH: button pressed. */
                press_seen = true;
                ESP_LOGI(TAG, "Button pressed; release to start recording.");
            } else if (press_seen) {
                /* Stable LOW after a press: button released -> record. */
                press_seen = false;
                (void)record_one_file();
                ESP_LOGI(TAG, "Ready for next recording.");
            }
        }

        vTaskDelay(pdMS_TO_TICKS(10));
    }
}

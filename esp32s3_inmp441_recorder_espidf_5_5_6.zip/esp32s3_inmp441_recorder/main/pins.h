#pragma once

#include "driver/gpio.h"

/*
 * ESP32-S3 N16R8 recommended example pinout.
 * Change the SD SPI pins here if your board uses different exposed GPIOs.
 *
 * Do NOT use GPIO26-GPIO32 for general IO.
 * On ESP32-S3 with octal PSRAM, do NOT use GPIO33-GPIO37.
 */

/* INMP441 I2S */
#define PIN_I2S_BCLK       GPIO_NUM_4
#define PIN_I2S_WS         GPIO_NUM_6
#define PIN_I2S_DIN        GPIO_NUM_7

/* SPI MicroSD */
#define PIN_SD_CS          GPIO_NUM_5
#define PIN_SD_SCK         GPIO_NUM_12
#define PIN_SD_MOSI        GPIO_NUM_11
#define PIN_SD_MISO        GPIO_NUM_10

/* User interface */
#define PIN_STATUS_LED     GPIO_NUM_13
#define PIN_RECORD_BUTTON  GPIO_NUM_14

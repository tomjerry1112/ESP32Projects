idf_component_register(
    SRCS "main.c"
    INCLUDE_DIRS "."
    REQUIRES
	esp_timer
        esp_driver_i2s
        esp_driver_gpio
        esp_driver_spi
        fatfs
        sdmmc
)

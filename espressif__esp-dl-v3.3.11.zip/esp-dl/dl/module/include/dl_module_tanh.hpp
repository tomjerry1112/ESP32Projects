#pragma once

#include "dl_module_base.hpp"
#include "dl_module_lut.hpp"

namespace dl {
namespace module {
/**
 * NOTE:
 *
 * @tparam feature_t supports float32, int16_t and int8_t,
 *         - float32 : stands for operation in float32
 *         - int16_t: stands for operation in int16_t, implemented by LUT
 *         - int8_t: stands for operation in int16_t, implemented by LUT
 */
class Tanh : public Module {
public:
    /**
     * @brief Construct a new Tanh object.
     *
     * @param name            name of module
     * @param inplace         inplace type.
     */
    Tanh(const char *name = NULL,
         module_inplace_t inplace = MODULE_NON_INPLACE,
         quant_type_t quant_type = QUANT_TYPE_NONE) :
        Module(name, inplace, quant_type)
    {
    }

    /**
     * @brief Destroy the Tanh object.
     */
    ~Tanh() {}

    std::vector<std::vector<int>> get_output_shape(std::vector<std::vector<int>> &input_shapes)
    {
        std::vector<std::vector<int>> output_shapes(1, input_shapes[0]);
        return output_shapes;
    }

    void forward(ModelContext *context, runtime_mode_t mode)
    {
        TensorBase *input = context->get_tensor(m_inputs_index[0]);
        TensorBase *output = context->get_tensor(m_outputs_index[0]);

        if (quant_type == QUANT_TYPE_SYMM_8BIT) {
            int8_t *input_ptr = (int8_t *)input->get_element_ptr();
            int8_t *output_ptr = (int8_t *)output->get_element_ptr();

            float input_scale = DL_SCALE(input->exponent);
            float output_scale = DL_RESCALE(output->exponent);
            for (size_t i = 0; i < input->size; i++) {
                float temp = math::tanh((float)input_ptr[i] * input_scale);
                tool::truncate(output_ptr[i], tool::round(temp * output_scale));
            }
        } else if (quant_type == QUANT_TYPE_SYMM_16BIT) {
            int16_t *input_ptr = (int16_t *)input->get_element_ptr();
            int16_t *output_ptr = (int16_t *)output->get_element_ptr();

            float input_scale = DL_SCALE(input->exponent);
            float output_scale = DL_RESCALE(output->exponent);
            for (size_t i = 0; i < input->size; i++) {
                float temp = math::tanh((float)input_ptr[i] * input_scale);
                tool::truncate(output_ptr[i], tool::round(temp * output_scale));
            }
        } else if (quant_type == QUANT_TYPE_FLOAT32) {
            float *input_ptr = (float *)input->get_element_ptr();
            float *output_ptr = (float *)output->get_element_ptr();

            for (size_t i = 0; i < input->size; i++) {
                output_ptr[i] = math::tanh(input_ptr[i]);
            }
        }
    }

    void forward_args(void *args) {}

    /**
     * @brief deserialize Tanh module instance by node serialization information
     */
    static Module *deserialize(fbs::FbsModel *fbs_model, std::string node_name)
    {
        Module *op = nullptr;
        quant_type_t quant_type;
        fbs_model->get_operation_attribute(node_name, "quant_type", quant_type);

        // Create module
        if (quant_type == QUANT_TYPE_SYMM_8BIT || quant_type == QUANT_TYPE_SYMM_16BIT) {
            if (LUT::has_lut(fbs_model, node_name)) {
                op = new LUT(node_name.c_str(), MODULE_INPLACE_CHANGED_BUFFER, quant_type);
            } else {
                op = new Tanh(node_name.c_str(), MODULE_INPLACE_CHANGED_BUFFER, quant_type);
            }
        } else {
            op = new Tanh(node_name.c_str(), MODULE_INPLACE_CHANGED_BUFFER, quant_type);
        }

        return op;
    }

    void print() { ESP_LOGI("Tanh", "quant_type: %s.", quant_type_to_string(quant_type)); }
};
} // namespace module
} // namespace dl

/**
 * @file dl_define_private.hpp
 * @brief All macro here is for internal only. Once the project is compiled to static library, these macro is not
 * effective.
 * @version 0.1
 * @date 2021-07-02
 *
 * @copyright Copyright (c) 2021
 *
 */

#pragma once
#include "sdkconfig.h"

#define DL_S16_BUFFER_TYPE                                                                                        \
    int64_t /*!< int32_t or int64_t. int32_t is twice as fast as int64_t in C/C++ implement. But int32_t may have \
               value overflow. */
#define DL_LOG_DETECT_LATENCY 0 /*!< - 1: print the latency of each parts of detect */
                                /*!< - 0: mute */

#define DL_FAST_MATH 0 /*!< - 1: use fast math functions, which may have lower accuracy. */
                       /*!< - 0: use accurate math functions. */

#if CONFIG_IDF_TARGET_ESP32 || CONFIG_IDF_TARGET_ESP32S3
#define CONFIG_XTENSA_BOOST 1
#else
#define CONFIG_XTENSA_BOOST 0
#endif

#if CONFIG_IDF_TARGET_ESP32S3
#define CONFIG_PIE_V1_BOOST 1
#else
#define CONFIG_PIE_V1_BOOST 0
#endif

#if CONFIG_IDF_TARGET_ESP32P4 || CONFIG_IDF_TARGET_ESP32S31
#define CONFIG_PIE_V2_BOOST 1
#else
#define CONFIG_PIE_V2_BOOST 0
#endif

#define CONFIG_ACCURATE_INFER 1

#if CONFIG_IDF_TARGET_ESP32P4 || CONFIG_IDF_TARGET_ESP32S31
#define CONFIG_ROUND_HALF_EVEN_ENABLED 1
#else
#define CONFIG_ROUND_HALF_EVEN_ENABLED 0
#endif

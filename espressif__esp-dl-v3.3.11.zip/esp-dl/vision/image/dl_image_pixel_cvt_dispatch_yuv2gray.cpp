#include "dl_image_color.hpp"
#include "dl_image_pixel_cvt_dispatch.hpp"
#include "dl_image_process.hpp"

namespace dl {
namespace image {
template <typename Func>
void pixel_cvt_dispatch_yuv2gray(const Func &func, pix_cvt_t pix_cvt_type, const pix_cvt_param_t &param)
{
    switch (pix_cvt_type) {
    case DL_IMAGE_PIX_CVT_YUYV2GRAY:
        func(YUV2Gray<true>());
        break;
    case DL_IMAGE_PIX_CVT_YUYV2GRAY_QINT8:
        func(YUV2Gray<true, NormQuant<int8_t, 1>>(std::get<NormQuant<int8_t, 1>>(param)));
        break;
    case DL_IMAGE_PIX_CVT_YUYV2GRAY_QINT16:
        func(YUV2Gray<true, NormQuant<int16_t, 1>>(std::get<NormQuant<int16_t, 1>>(param)));
        break;
    case DL_IMAGE_PIX_CVT_UYVY2GRAY:
        func(YUV2Gray<false>());
        break;
    case DL_IMAGE_PIX_CVT_UYVY2GRAY_QINT8:
        func(YUV2Gray<false, NormQuant<int8_t, 1>>(std::get<NormQuant<int8_t, 1>>(param)));
        break;
    case DL_IMAGE_PIX_CVT_UYVY2GRAY_QINT16:
        func(YUV2Gray<false, NormQuant<int16_t, 1>>(std::get<NormQuant<int16_t, 1>>(param)));
        break;
    default:
        return;
    }
}

template void pixel_cvt_dispatch_yuv2gray<CvtPixelFunctor>(const CvtPixelFunctor &func,
                                                           pix_cvt_t pix_cvt_type,
                                                           const pix_cvt_param_t &param);
#if CONFIG_PIE_V2_BOOST
template void pixel_cvt_dispatch_yuv2gray<ImageTransformer::TransformNNFunctor<true>>(
    const ImageTransformer::TransformNNFunctor<true> &func, pix_cvt_t pix_cvt_type, const pix_cvt_param_t &param);
#endif
template void pixel_cvt_dispatch_yuv2gray<ImageTransformer::TransformNNFunctor<false>>(
    const ImageTransformer::TransformNNFunctor<false> &func, pix_cvt_t pix_cvt_type, const pix_cvt_param_t &param);
} // namespace image
} // namespace dl

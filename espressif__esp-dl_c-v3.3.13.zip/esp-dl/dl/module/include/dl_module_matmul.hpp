#pragma once

#include "dl_base_conv2d.hpp"
#include "dl_base_conv_args.hpp"
#include "dl_base_conv_select.hpp"
#include "dl_base_depthwise_conv2d.hpp"
#include "dl_base_matmul.hpp"
#include "dl_module_base.hpp"
#include <typeinfo>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

namespace dl {
namespace module {

/**
 * @brief Activation(MatMul(input0, input1)).
 *
 */
class MatMul : public Module {
private:
    activation_type_t
        m_activation; /*!< activation of MatMul, if you don't specify anything, no activation is applied */
    bool m_input1_native_kn;
    bool m_running_native_kernel;
    dl_kernel_erased_t m_fn[3] = {};

public:
    /**
     * @brief Construct a new MatMul object.
     *
     * @param activation      activation of MatMul, if you don't specify anything, no activation is applied
     * @param name            name of module
     */
    MatMul(activation_type_t activation = Linear,
           const char *name = nullptr,
           quant_type_t quant_type = QUANT_TYPE_NONE,
           bool input1_native_kn = false) :
        Module(name, MODULE_NON_INPLACE, quant_type),
        m_activation(activation),
        m_input1_native_kn(input1_native_kn),
        m_running_native_kernel(false)
    {
    }

    /**
     * @brief Destroy the MatMul object.
     *
     */
    ~MatMul() {}

    /**
     * @brief Calculate the output shape
     *
     * @param input_shapes The shape of inputs
     *
     * @return output shapes
     */
    std::vector<std::vector<int>> get_output_shape(std::vector<std::vector<int>> &input_shapes)
    {
        // refer to https://pytorch.org/docs/stable/generated/torch.matmul.html#torch-matmul
        std::vector<int> output_shape;
        if (input_shapes[0].size() == 1 && input_shapes[1].size() == 1) {
            assert(input_shapes[0][0] == input_shapes[1][0]);
            output_shape.push_back(1);

        } else if (input_shapes[0].size() == 2 && input_shapes[1].size() == 2) {
            assert(input_shapes[0][1] == input_shapes[1][0]);
            output_shape = {input_shapes[0][0], input_shapes[1][1]};

        } else if (input_shapes[0].size() == 1 && input_shapes[1].size() == 2) {
            assert(input_shapes[0][0] == input_shapes[1][0]);
            output_shape = {input_shapes[1][1]};

        } else if (input_shapes[0].size() == 2 && input_shapes[1].size() == 1) {
            assert(input_shapes[0][1] == input_shapes[1][0]);
            output_shape = {input_shapes[0][0]};

        } else if (input_shapes[0].size() == 1 && input_shapes[1].size() > 2) {
            assert(input_shapes[0][0] == input_shapes[1][input_shapes[1].size() - 2]);
            output_shape.assign(input_shapes[1].begin(), input_shapes[1].begin() + input_shapes[1].size() - 2);
            output_shape.push_back(input_shapes[1][input_shapes[1].size() - 1]);

        } else if (input_shapes[0].size() > 2 && input_shapes[1].size() == 1) {
            assert(input_shapes[0].back() == input_shapes[1][0]);
            output_shape.assign(input_shapes[0].begin(), input_shapes[0].begin() + input_shapes[0].size() - 1);

        } else if (std::max(input_shapes[0].size(), input_shapes[1].size()) == 3) {
            assert(input_shapes[0].back() == input_shapes[1][input_shapes[1].size() - 2]);
            int input0_batch = input_shapes[0].size() == 2 ? 1 : input_shapes[0][0];
            int input1_batch = input_shapes[1].size() == 2 ? 1 : input_shapes[1][0];
            assert(input0_batch == 1 || input1_batch == 1 || input0_batch == input1_batch);
            output_shape = {std::max(input0_batch, input1_batch),
                            input_shapes[0][input_shapes[0].size() - 2],
                            input_shapes[1].back()};

        } else if (std::max(input_shapes[0].size(), input_shapes[1].size()) == 4) {
            assert(input_shapes[0].back() == input_shapes[1][input_shapes[1].size() - 2]);
            int input0_batch0 = input_shapes[0].size() == 2 ? 1 : input_shapes[0].size() == 3 ? 1 : input_shapes[0][0];
            int input1_batch0 = input_shapes[1].size() == 2 ? 1 : input_shapes[1].size() == 3 ? 1 : input_shapes[1][0];
            assert(input0_batch0 == 1 || input1_batch0 == 1 || input0_batch0 == input1_batch0);

            int input0_batch1 = input_shapes[0].size() == 2 ? 1
                : input_shapes[0].size() == 3               ? input_shapes[0][0]
                                                            : input_shapes[0][1];
            int input1_batch1 = input_shapes[1].size() == 2 ? 1
                : input_shapes[1].size() == 3               ? input_shapes[1][0]
                                                            : input_shapes[1][1];
            assert(input0_batch1 == 1 || input1_batch1 == 1 || input0_batch1 == input1_batch1);

            output_shape = {std::max(input0_batch0, input1_batch0),
                            std::max(input0_batch1, input1_batch1),
                            input_shapes[0][input_shapes[0].size() - 2],
                            input_shapes[1].back()};

        } else {
            ESP_LOGE("MatMul",
                     "Impossible matmul, input0 dims: %d, input1 dims: %d",
                     input_shapes[0].size(),
                     input_shapes[1].size());
        }
        std::vector<std::vector<int>> output_shapes(1, output_shape);
        return output_shapes;
    }

    void forward_args(void *args)
    {
        if (m_running_native_kernel) {
            if (quant_type == QUANT_TYPE_SYMM_8BIT) {
                base::matmul<int8_t>(*static_cast<base::MatMulArgs<int8_t> *>(args));
            } else if (quant_type == QUANT_TYPE_SYMM_16BIT) {
                base::matmul<int16_t>(*static_cast<base::MatMulArgs<int16_t> *>(args));
            }
            return;
        }

        base::conv2d(args, quant_type, m_fn[0], m_fn[1], m_fn[2]);
    }

    void run_conv_args(base::ConvOpArgs &m_args)
    {
        int task_size = m_args.size();
        if (task_size < 1 || !base::dl_conv_ensure_kernels(m_fn, m_args.get_args(0), 0, quant_type, "MatMul")) {
            return;
        }
        if (task_size == 1) {
            forward_args((void *)&m_args.get_args(0));
        } else if (task_size == 2) {
            ESP_LOGI("MatMul", "two task...");
            module_forward_dual_core(this, (void *)&m_args.get_args(0), (void *)&m_args.get_args(1));
        } else {
            ESP_LOGE("MatMul", "Only support task size is 1 or 2, currently task size is %d", task_size);
        }
    }

    template <typename T>
    void run_native_matrix(
        const T *input0, const T *input1, T *output, int m, int n, int k, int mac_shift, runtime_mode_t mode)
    {
        base::MatMulArgs<T> args;
        args.a = input0;
        args.b = input1;
        args.c = output;
        args.m = m;
        args.n = n;
        args.k = k;
        args.a_stride = k;
        args.b_stride = n;
        args.c_stride = n;
        args.row_start = 0;
        args.row_end = m;
        args.mac_shift = mac_shift;
        args.activation = m_activation;

        const bool use_dual_core =
            m > 1 && (mode == RUNTIME_MODE_MULTI_CORE || (mode == RUNTIME_MODE_AUTO && m >= 100 && n >= 50));
        if (!use_dual_core) {
            base::matmul<T>(args);
            return;
        }

        base::MatMulArgs<T> args_bottom = args;
        args.row_end = m / 2;
        args_bottom.row_start = args.row_end;
        module_forward_dual_core(this, static_cast<void *>(&args), static_cast<void *>(&args_bottom));
    }

    template <typename T>
    void forward_native_template(ModelContext *context, runtime_mode_t mode)
    {
        TensorBase *input0 = context->get_tensor(m_inputs_index[0]);
        TensorBase *input1 = context->get_tensor(m_inputs_index[1]);
        TensorBase *output = context->get_tensor(m_outputs_index[0]);
        const std::vector<int> &input0_shape = input0->get_shape();
        const std::vector<int> &input1_shape = input1->get_shape();

        assert(m_activation == Linear || m_activation == ReLU);
        assert(input0_shape.size() >= 1 && input0_shape.size() <= 4);
        assert(input1_shape.size() >= 1 && input1_shape.size() <= 4);

        const bool input0_vector = input0_shape.size() == 1;
        const bool input1_vector = input1_shape.size() == 1;
        const int m = input0_vector ? 1 : input0_shape[input0_shape.size() - 2];
        const int k = input0_shape.back();
        const int input1_k = input1_vector ? input1_shape[0] : input1_shape[input1_shape.size() - 2];
        const int n = input1_vector ? 1 : input1_shape.back();
        assert(k == input1_k);

        const int input0_batch_rank = input0_vector ? 0 : input0_shape.size() - 2;
        const int input1_batch_rank = input1_vector ? 0 : input1_shape.size() - 2;
        const int batch_rank = std::max(input0_batch_rank, input1_batch_rank);
        std::vector<int> output_batch_shape(batch_rank, 1);
        std::vector<int> input0_batch_shape(batch_rank, 1);
        std::vector<int> input1_batch_shape(batch_rank, 1);

        for (int i = 0; i < input0_batch_rank; ++i) {
            input0_batch_shape[batch_rank - input0_batch_rank + i] = input0_shape[i];
        }
        for (int i = 0; i < input1_batch_rank; ++i) {
            input1_batch_shape[batch_rank - input1_batch_rank + i] = input1_shape[i];
        }

        int batch_count = 1;
        for (int i = 0; i < batch_rank; ++i) {
            const int input0_batch = input0_batch_shape[i];
            const int input1_batch = input1_batch_shape[i];
            assert(input0_batch == 1 || input1_batch == 1 || input0_batch == input1_batch);
            output_batch_shape[i] = std::max(input0_batch, input1_batch);
            batch_count *= output_batch_shape[i];
        }

        const T *input0_data = static_cast<const T *>(input0->get_element_ptr());
        const T *input1_data = static_cast<const T *>(input1->get_element_ptr());
        T *output_data = static_cast<T *>(output->get_element_ptr());
        const int mac_shift = output->exponent - input0->exponent - input1->exponent;

        m_running_native_kernel = true;
        for (int batch = 0; batch < batch_count; ++batch) {
            int remainder = batch;
            int input0_batch_index = 0;
            int input1_batch_index = 0;
            int input0_batch_stride = 1;
            int input1_batch_stride = 1;
            for (int i = batch_rank - 1; i >= 0; --i) {
                const int coordinate = remainder % output_batch_shape[i];
                remainder /= output_batch_shape[i];
                input0_batch_index += (input0_batch_shape[i] == 1 ? 0 : coordinate) * input0_batch_stride;
                input1_batch_index += (input1_batch_shape[i] == 1 ? 0 : coordinate) * input1_batch_stride;
                input0_batch_stride *= input0_batch_shape[i];
                input1_batch_stride *= input1_batch_shape[i];
            }

            run_native_matrix(input0_data + input0_batch_index * m * k,
                              input1_data + input1_batch_index * k * n,
                              output_data + batch * m * n,
                              m,
                              n,
                              k,
                              mac_shift,
                              mode);
        }
        m_running_native_kernel = false;
    }

    void forward_as_conv(ModelContext *context, runtime_mode_t mode)
    {
        std::vector<int> padding(4, 0);
        TensorBase *input0 = context->get_tensor(m_inputs_index[0]);
        TensorBase *input1 = context->get_tensor(m_inputs_index[1]);
        TensorBase *output = context->get_tensor(m_outputs_index[0]);
        std::vector<int> origin_input0_shape = input0->get_shape();
        std::vector<int> origin_input1_shape = input1->get_shape();
        std::vector<int> origin_output_shape = output->get_shape();

        // input: MK -> NHWC; filter: KN -> HWIO; output: MN -> NHWC
        if (origin_input0_shape.size() <= 2 && origin_input1_shape.size() <= 2) {
            if (origin_input0_shape.size() == 1 && origin_input1_shape.size() == 1) {
                // dot product
                // input: NHWC
                input0->set_shape({1, 1, 1, origin_input0_shape[0]});
                // filter: HWIO
                input1->set_shape({1, 1, origin_input1_shape[0], 1});
                // output: NHWC
                output->set_shape({1, 1, 1, 1});

            } else if (origin_input0_shape.size() == 2 && origin_input1_shape.size() == 2) {
                // matrix multiply
                // input: NHWC
                input0->set_shape({1, 1, origin_input0_shape[0], origin_input0_shape[1]});
                // filter: HWIO
                input1->set_shape({1, 1, origin_input1_shape[0], origin_input1_shape[1]});
                // output: NHWC
                output->set_shape({1, 1, origin_output_shape[0], origin_output_shape[1]});

            } else if (origin_input0_shape.size() == 1 && origin_input1_shape.size() == 2) {
                // input: NHWC
                input0->set_shape({1, 1, 1, origin_input0_shape[0]});
                // filter: HWIO
                input1->set_shape({1, 1, origin_input1_shape[0], origin_input1_shape[1]});
                // output: NHWC
                output->set_shape({1, 1, 1, origin_output_shape[0]});

            } else if (origin_input0_shape.size() == 2 && origin_input1_shape.size() == 1) {
                // input: NHWC
                input0->set_shape({1, 1, origin_input0_shape[0], origin_input0_shape[1]});
                // filter: HWIO
                input1->set_shape({1, 1, origin_input1_shape[0], 1});
                // output: NHWC
                output->set_shape({1, 1, origin_output_shape[0], 1});
            }

            base::ConvOpArgs m_args(output,
                                    input0,
                                    padding,
                                    input1 /*filter*/,
                                    {1, 1} /*strides*/,
                                    {1, 1} /*dilations*/,
                                    1 /*group*/,
                                    nullptr /*bias*/,
                                    m_activation,
                                    nullptr,
                                    mode,
                                    quant_type); // do not support PReLU and Leaky RelU
            run_conv_args(m_args);

        } else {
            // batched matrix multiply
            size_t input0_dtype_bytes = input0->get_dtype_bytes();
            void *input0_element = input0->get_element_ptr();
            size_t input1_dtype_bytes = input1->get_dtype_bytes();
            void *input1_element = input1->get_element_ptr();
            size_t output_dtype_bytes = output->get_dtype_bytes();
            void *output_element = output->get_element_ptr();

            if (origin_input0_shape.size() == 1 && origin_input1_shape.size() > 2) {
                int input1_batch_size = 1;
                for (int i = 0; i < origin_input1_shape.size() - 2; i++) {
                    input1_batch_size *= origin_input1_shape[i];
                }

                int c = origin_input1_shape[origin_input1_shape.size() - 2];
                int n = origin_input1_shape.back();
                int align = quant_type == QUANT_TYPE_SYMM_8BIT ? 16 : 8;
                bool is_align = (c * n % align) == 0;
                input1->set_shape({input1_batch_size, c, n});

                // input: NHWC
                input0->set_shape({1, 1, 1, origin_input0_shape.back()});
                // output: NHWC
                output->set_shape({input1_batch_size, origin_output_shape.back()});

                TensorBase input1_tmp({1, 1, c, n} /*shape*/,
                                      input1_element /*element*/,
                                      input1->exponent /*exponent*/,
                                      input1->dtype /*dtype*/,
                                      is_align ? false : true /*deep*/,
                                      input1->caps /*caps*/);

                for (int i = 0; i < input1_batch_size; i++) {
                    // filter: HWIO
                    if (!is_align) {
                        input1_tmp.assign({1, 1, c, n} /*shape*/,
                                          static_cast<char *>(input1_element) +
                                              input1_dtype_bytes * input1->get_element_index({i, 0, 0}) /*element*/,
                                          input1->exponent /*exponent*/,
                                          input1->dtype /*dtype*/);
                    } else {
                        input1_tmp.set_element_ptr(static_cast<char *>(input1_element) +
                                                   input1_dtype_bytes * input1->get_element_index({i, 0, 0}));
                    }

                    // output: NHWC
                    TensorBase output_tmp({1, 1, 1, origin_output_shape.back()} /*shape*/,
                                          static_cast<char *>(output_element) +
                                              output_dtype_bytes * output->get_element_index({i, 0}) /*element*/,
                                          output->exponent /*exponent*/,
                                          output->dtype /*dtype*/,
                                          false /*deep*/,
                                          output->caps /*caps*/);

                    base::ConvOpArgs m_args(&output_tmp,
                                            input0,
                                            padding,
                                            &input1_tmp /*filter*/,
                                            {1, 1} /*strides*/,
                                            {1, 1} /*dilations*/,
                                            1 /*group*/,
                                            nullptr /*bias*/,
                                            m_activation,
                                            nullptr,
                                            mode,
                                            quant_type); // do not support PReLU and Leaky RelU
                    run_conv_args(m_args);
                }

            } else if (origin_input0_shape.size() > 2 && origin_input1_shape.size() == 1) {
                int input0_batch_size = 1;
                for (int i = 0; i < origin_input0_shape.size() - 2; i++) {
                    input0_batch_size *= origin_input0_shape[i];
                }
                input0->set_shape({input0_batch_size,
                                   origin_input0_shape[origin_input0_shape.size() - 2],
                                   origin_input0_shape.back()});
                // filter: HWIO
                input1->set_shape({1, 1, origin_input1_shape.back(), 1});
                // output: NHWC
                output->set_shape({input0_batch_size, origin_output_shape.back()});

                for (int i = 0; i < input0_batch_size; i++) {
                    // input: NHWC
                    TensorBase input0_tmp({1,
                                           1,
                                           origin_input0_shape[origin_input0_shape.size() - 2],
                                           origin_input0_shape.back()} /*shape*/,
                                          static_cast<char *>(input0_element) +
                                              input0_dtype_bytes * input0->get_element_index({i, 0, 0}) /*element*/,
                                          input0->exponent /*exponent*/,
                                          input0->dtype /*dtype*/,
                                          false /*deep*/,
                                          input0->caps /*caps*/);
                    // output: NHWC
                    TensorBase output_tmp({1, 1, origin_output_shape.back(), 1} /*shape*/,
                                          static_cast<char *>(output_element) +
                                              output_dtype_bytes * output->get_element_index({i, 0}) /*element*/,
                                          output->exponent /*exponent*/,
                                          output->dtype /*dtype*/,
                                          false /*deep*/,
                                          output->caps /*caps*/);

                    base::ConvOpArgs m_args(&output_tmp,
                                            &input0_tmp,
                                            padding,
                                            input1 /*filter*/,
                                            {1, 1} /*strides*/,
                                            {1, 1} /*dilations*/,
                                            1 /*group*/,
                                            nullptr /*bias*/,
                                            m_activation,
                                            nullptr,
                                            mode,
                                            quant_type); // do not support PReLU and Leaky RelU
                    run_conv_args(m_args);
                }

            } else if (std::max(origin_input0_shape.size(), origin_input1_shape.size()) == 3) {
                int input0_batch = origin_input0_shape.size() == 2 ? 1 : origin_input0_shape[0];
                int input1_batch = origin_input1_shape.size() == 2 ? 1 : origin_input1_shape[0];

                int c = origin_input1_shape[origin_input1_shape.size() - 2];
                int n = origin_input1_shape.back();
                int align = quant_type == QUANT_TYPE_SYMM_8BIT ? 16 : 8;
                bool is_align = (c * n % align) == 0;
                input0->set_shape(
                    {input0_batch, origin_input0_shape[origin_input0_shape.size() - 2], origin_input0_shape.back()});
                input1->set_shape({input1_batch, c, n});
                int max_batch = std::max(input0_batch, input1_batch);

                TensorBase input1_tmp({1, 1, c, n} /*shape*/,
                                      input1_element /*element*/,
                                      input1->exponent /*exponent*/,
                                      input1->dtype /*dtype*/,
                                      is_align ? false : true /*deep*/,
                                      input1->caps /*caps*/);

                for (int i = 0; i < max_batch; i++) {
                    // input: NHWC
                    int input0_i = input0_batch == 1 ? 0 : i;
                    TensorBase input0_tmp({1,
                                           1,
                                           origin_input0_shape[origin_input0_shape.size() - 2],
                                           origin_input0_shape.back()} /*shape*/,
                                          static_cast<char *>(input0_element) +
                                              input0_dtype_bytes *
                                                  input0->get_element_index({input0_i, 0, 0}) /*element*/,
                                          input0->exponent /*exponent*/,
                                          input0->dtype /*dtype*/,
                                          false /*deep*/,
                                          input0->caps /*caps*/);

                    // filter: HWIO
                    int input1_i = input1_batch == 1 ? 0 : i;
                    if (!is_align) {
                        input1_tmp.assign({1, 1, c, n} /*shape*/,
                                          static_cast<char *>(input1_element) +
                                              input1_dtype_bytes *
                                                  input1->get_element_index({input1_i, 0, 0}) /*element*/,
                                          input1->exponent /*exponent*/,
                                          input1->dtype /*dtype*/);
                    } else {
                        input1_tmp.set_element_ptr(static_cast<char *>(input1_element) +
                                                   input1_dtype_bytes * input1->get_element_index({input1_i, 0, 0}));
                    }

                    // output: NHWC
                    TensorBase output_tmp({1,
                                           1,
                                           origin_output_shape[origin_output_shape.size() - 2],
                                           origin_output_shape.back()} /*shape*/,
                                          static_cast<char *>(output_element) +
                                              output_dtype_bytes * output->get_element_index({i, 0, 0}) /*element*/,
                                          output->exponent /*exponent*/,
                                          output->dtype /*dtype*/,
                                          false /*deep*/,
                                          output->caps /*caps*/);

                    base::ConvOpArgs m_args(&output_tmp,
                                            &input0_tmp,
                                            padding,
                                            &input1_tmp /*filter*/,
                                            {1, 1} /*strides*/,
                                            {1, 1} /*dilations*/,
                                            1 /*group*/,
                                            nullptr /*bias*/,
                                            m_activation,
                                            nullptr,
                                            mode,
                                            quant_type); // do not support PReLU and Leaky RelU
                    run_conv_args(m_args);
                }

            } else if (std::max(origin_input0_shape.size(), origin_input1_shape.size()) == 4) {
                int input0_batch0 = origin_input0_shape.size() == 2 ? 1
                    : origin_input0_shape.size() == 3               ? 1
                                                                    : origin_input0_shape[0];
                int input1_batch0 = origin_input1_shape.size() == 2 ? 1
                    : origin_input1_shape.size() == 3               ? 1
                                                                    : origin_input1_shape[0];
                int input0_batch1 = origin_input0_shape.size() == 2 ? 1
                    : origin_input0_shape.size() == 3               ? origin_input0_shape[0]
                                                                    : origin_input0_shape[1];
                int input1_batch1 = origin_input1_shape.size() == 2 ? 1
                    : origin_input1_shape.size() == 3               ? origin_input1_shape[0]
                                                                    : origin_input1_shape[1];

                int c = origin_input1_shape[origin_input1_shape.size() - 2];
                int n = origin_input1_shape.back();
                int align = quant_type == QUANT_TYPE_SYMM_8BIT ? 16 : 8;
                bool is_align = (c * n % align) == 0;
                input0->set_shape({input0_batch0,
                                   input0_batch1,
                                   origin_input0_shape[origin_input0_shape.size() - 2],
                                   origin_input0_shape.back()});
                input1->set_shape({input1_batch0, input1_batch1, c, n});
                int max_batch0 = std::max(input0_batch0, input1_batch0);
                int max_batch1 = std::max(input0_batch1, input1_batch1);

                TensorBase input1_tmp({1, 1, c, n} /*shape*/,
                                      input1_element /*element*/,
                                      input1->exponent /*exponent*/,
                                      input1->dtype /*dtype*/,
                                      is_align ? false : true /*deep*/,
                                      input1->caps /*caps*/);

                for (int i = 0; i < max_batch0; i++) {
                    int input0_i = input0_batch0 == 1 ? 0 : i;
                    int input1_i = input1_batch0 == 1 ? 0 : i;

                    for (int j = 0; j < max_batch1; j++) {
                        int input0_j = input0_batch1 == 1 ? 0 : j;
                        int input1_j = input1_batch1 == 1 ? 0 : j;

                        // input: NHWC
                        TensorBase input0_tmp({1,
                                               1,
                                               origin_input0_shape[origin_input0_shape.size() - 2],
                                               origin_input0_shape.back()} /*shape*/,
                                              static_cast<char *>(input0_element) +
                                                  input0_dtype_bytes *
                                                      input0->get_element_index({input0_i, input0_j, 0, 0}) /*element*/,
                                              input0->exponent /*exponent*/,
                                              input0->dtype /*dtype*/,
                                              false /*deep*/,
                                              input0->caps /*caps*/);

                        // filter: HWIO
                        if (!is_align) {
                            input1_tmp.assign({1, 1, c, n} /*shape*/,
                                              static_cast<char *>(input1_element) +
                                                  input1_dtype_bytes *
                                                      input1->get_element_index({input1_i, input1_j, 0, 0}) /*element*/,
                                              input1->exponent /*exponent*/,
                                              input1->dtype /*dtype*/);
                        } else {
                            input1_tmp.set_element_ptr(static_cast<char *>(input1_element) +
                                                       input1_dtype_bytes *
                                                           input1->get_element_index({input1_i, input1_j, 0, 0}));
                        }

                        // output: NHWC
                        TensorBase output_tmp({1,
                                               1,
                                               origin_output_shape[origin_output_shape.size() - 2],
                                               origin_output_shape.back()} /*shape*/,
                                              static_cast<char *>(output_element) +
                                                  output_dtype_bytes *
                                                      output->get_element_index({i, j, 0, 0}) /*element*/,
                                              output->exponent /*exponent*/,
                                              output->dtype /*dtype*/,
                                              false /*deep*/,
                                              output->caps /*caps*/);

                        base::ConvOpArgs m_args(&output_tmp,
                                                &input0_tmp,
                                                padding,
                                                &input1_tmp /*filter*/,
                                                {1, 1} /*strides*/,
                                                {1, 1} /*dilations*/,
                                                1 /*group*/,
                                                nullptr /*bias*/,
                                                m_activation,
                                                nullptr,
                                                mode,
                                                quant_type); // do not support PReLU and Leaky RelU
                        run_conv_args(m_args);
                    }
                }

            } else {
                ESP_LOGE("MatMul",
                         "Impossible matmul, input0 dims: %d, input1 dims: %d",
                         origin_input0_shape.size(),
                         origin_input1_shape.size());
            }
        }

        input0->set_shape(origin_input0_shape);
        input1->set_shape(origin_input1_shape);
        output->set_shape(origin_output_shape);
    }

    void forward(ModelContext *context, runtime_mode_t mode = RUNTIME_MODE_AUTO)
    {
        if (m_input1_native_kn && quant_type == QUANT_TYPE_SYMM_8BIT) {
            forward_native_template<int8_t>(context, mode);
            return;
        }
        if (m_input1_native_kn && quant_type == QUANT_TYPE_SYMM_16BIT) {
            forward_native_template<int16_t>(context, mode);
            return;
        }
        forward_as_conv(context, mode);
    }

    /**
     * @brief deserialize MatMul module instance by node serialization information
     */
    static Module *deserialize(fbs::FbsModel *fbs_model, std::string node_name)
    {
        Module *matmul_op = nullptr;

        activation_type_t activation_type;
        quant_type_t quant_type = QUANT_TYPE_NONE;
        std::string quant_type_str;
        std::string input1_layout = "packed";
        fbs_model->get_operation_attribute(node_name, "activation", activation_type);
        // Prebuilt fbs_model only maps S8/S16/F32. Read the raw string first so
        // W8A16 is not lost if the library treats it as unknown.
        if (fbs_model->get_operation_attribute(node_name, "quant_type", quant_type_str) == ESP_OK &&
            quant_type_str == "W8A16") {
            quant_type = QUANT_TYPE_SYMM_W8A16;
        } else {
            fbs_model->get_operation_attribute(node_name, "quant_type", quant_type);
        }
        fbs_model->get_operation_attribute(node_name, "input1_layout", input1_layout);

        // Create module
        if (quant_type == QUANT_TYPE_SYMM_8BIT || quant_type == QUANT_TYPE_SYMM_16BIT ||
            quant_type == QUANT_TYPE_SYMM_W8A16) {
            matmul_op = new MatMul(activation_type, node_name.c_str(), quant_type, input1_layout == "native_kn");
        }

        return matmul_op;
    }

    void print()
    {
        ESP_LOGI("MatMul",
                 "activation: %s, "
                 "quant_type: %s, "
                 "input1_layout: %s.",
                 activation_type_to_string(m_activation),
                 quant_type_to_string(quant_type),
                 m_input1_native_kn ? "native_kn" : "packed");
    }
};
} // namespace module
} // namespace dl

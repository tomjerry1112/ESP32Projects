#include "dl_tensor_base.hpp"
#include "dl_base_isa.hpp"
#include "dl_base_pad.hpp"
#include "dl_base_requantize_linear.hpp"
#include "esp_random.h"
#include <cstdint>
#include <cstring>
#include <iostream>
#include <type_traits>
namespace dl {

static bool is_nan(float value)
{
    uint32_t bits;
    memcpy(&bits, &value, sizeof(bits));
    return (bits & UINT32_C(0x7fffffff)) > UINT32_C(0x7f800000);
}

template <typename RT, typename T>
RT quantize(T input, float inv_scale)
{
    int output = tool::round(input * inv_scale);

    if constexpr (sizeof(RT) == 1) {
        output = DL_CLIP(output, DL_QUANT8_MIN, DL_QUANT8_MAX);
    } else {
        output = DL_CLIP(output, DL_QUANT16_MIN, DL_QUANT16_MAX);
    }

    return static_cast<RT>(output);
}

template int8_t quantize<int8_t, float>(float input, float scale);
template int16_t quantize<int16_t, float>(float input, float scale);
template int8_t quantize<int8_t, double>(double input, float scale);
template int16_t quantize<int16_t, double>(double input, float scale);

template <typename T, typename RT>
RT dequantize(T input, float scale)
{
    RT output = static_cast<RT>(input) * scale;
    return output;
}

template float dequantize<int8_t, float>(int8_t input, float scale);
template float dequantize<int16_t, float>(int16_t input, float scale);
template double dequantize<int8_t, double>(int8_t input, float scale);
template double dequantize<int16_t, double>(int16_t input, float scale);

size_t dtype_sizeof(dtype_t dtype)
{
    switch (dtype) {
    case DATA_TYPE_FLOAT:
        return sizeof(float);
    case DATA_TYPE_INT8:
        return sizeof(int8_t);
    case DATA_TYPE_UINT8:
        return sizeof(uint8_t);
    case DATA_TYPE_INT16:
        return sizeof(int16_t);
    case DATA_TYPE_UINT16:
        return sizeof(uint16_t);
    case DATA_TYPE_INT32:
        return sizeof(int32_t);
    case DATA_TYPE_UINT32:
        return sizeof(uint32_t);
    case DATA_TYPE_INT64:
        return sizeof(int64_t);
    case DATA_TYPE_UINT64:
        return sizeof(uint64_t);
    case DATA_TYPE_BOOL:
        return sizeof(bool);
    case DATA_TYPE_DOUBLE:
        return sizeof(double);
    case DATA_TYPE_FLOAT16:
        return 2;
    default:
        return 1;
    }
    return 1;
}

const char *dtype_to_string(dtype_t dtype)
{
    switch (dtype) {
    case DATA_TYPE_FLOAT:
        return "float";
    case DATA_TYPE_UINT8:
        return "uint8";
    case DATA_TYPE_INT8:
        return "int8";
    case DATA_TYPE_UINT16:
        return "uint16";
    case DATA_TYPE_INT16:
        return "int16";
    case DATA_TYPE_INT32:
        return "int32";
    case DATA_TYPE_UINT32:
        return "unit32";
    case DATA_TYPE_DOUBLE:
        return "double";
    case DATA_TYPE_STRING:
        return "string";
    case DATA_TYPE_BOOL:
        return "bool";
    case DATA_TYPE_FLOAT16:
        return "float16";
    case DATA_TYPE_INT64:
        return "int64";
    case DATA_TYPE_UINT64:
        return "uint64";
    case DATA_TYPE_UNDEFINED:
        return "undefined";
    default:
        return "undefined";
    }
    return "undefined";
}

const char *activation_type_to_string(activation_type_t type)
{
    switch (type) {
    case Linear:
        return "None";
    case ReLU:
        return "ReLU";
    case LeakyReLU:
        return "LeakyReLU";
    case PReLU:
        return "PReLU";
    default:
        return "None";
    }
    return "None";
}

const char *quant_type_to_string(quant_type_t type)
{
    switch (type) {
    case QUANT_TYPE_SYMM_8BIT:
        return "symm 8bit";
    case QUANT_TYPE_SYMM_16BIT:
        return "symm 16bit";
    case QUANT_TYPE_SYMM_32BIT:
        return "symm 32bit";
    case QUANT_TYPE_SYMM_W8A16:
        return "symm w8a16";
    case QUANT_TYPE_FLOAT32:
        return "float";
    default:
        return "None";
    }
    return "None";
}

TensorBase::TensorBase(
    std::vector<int> shape, const void *element, int exponent, dtype_t dtype, bool deep, uint32_t caps)
{
    this->set_shape(shape);
    this->exponent = exponent;
    this->dtype = dtype;
    this->cache = nullptr;
    size_t dtype_bytes = this->get_dtype_bytes();
    size_t aligned_size = this->get_aligned_size();
    if (element) {
        if (deep) {
            this->auto_free = true;
            this->data = tool::calloc_aligned(aligned_size, dtype_bytes, caps);
            tool::copy_memory(this->data, const_cast<void *>(element), this->get_size() * dtype_bytes);
        } else {
            this->auto_free = false;
            this->data = const_cast<void *>(element);
        }
    } else {
        this->auto_free = true;
        this->data = tool::calloc_aligned(aligned_size, dtype_bytes, caps);
    }
    if ((!element || deep) && !this->data) {
        ESP_LOGE(
            "TensorBase",
            "Failed to alloc %.2fKB RAM, largest available PSRAM block size %.2fKB, internal RAM block size %.2fKB",
            size / 1024.f,
            heap_caps_get_largest_free_block(MALLOC_CAP_SPIRAM) / 1024.f,
            heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL) / 1024.f);
    }
    this->caps = caps;
}

TensorBase::TensorBase(std::vector<int> shape,
                       const void *element,
                       const std::vector<int> &exponents,
                       dtype_t dtype,
                       bool deep,
                       uint32_t caps)
{
    this->set_shape(shape);
    this->exponent = ExponentInfo(exponents);
    this->dtype = dtype;
    this->cache = nullptr;
    this->caps = caps;
    if (!this->exponent.is_valid()) {
        ESP_LOGE(
            "TensorBase", "Failed to alloc %d per-channel exponents, the tensor is left empty.", (int)exponents.size());
        this->auto_free = false;
        this->data = nullptr;
        return;
    }
    size_t dtype_bytes = this->get_dtype_bytes();
    size_t aligned_size = this->get_aligned_size();
    if (element) {
        if (deep) {
            this->auto_free = true;
            this->data = tool::calloc_aligned(aligned_size, dtype_bytes, caps);
            tool::copy_memory(this->data, const_cast<void *>(element), this->get_size() * dtype_bytes);
        } else {
            this->auto_free = false;
            this->data = const_cast<void *>(element);
        }
    } else {
        this->auto_free = true;
        this->data = tool::calloc_aligned(aligned_size, dtype_bytes, caps);
    }
    if ((!element || deep) && !this->data) {
        ESP_LOGE(
            "TensorBase",
            "Failed to alloc %.2fKB RAM, largest available PSRAM block size %.2fKB, internal RAM block size %.2fKB",
            size / 1024.f,
            heap_caps_get_largest_free_block(MALLOC_CAP_SPIRAM) / 1024.f,
            heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL) / 1024.f);
    }
}

bool TensorBase::assign(TensorBase *tensor)
{
    if (tensor == nullptr || this->get_size() != tensor->get_size()) {
        return false;
    }

    // Only the weights may use per-channel quantization.
    bool this_per_channel = this->exponent.is_per_channel();
    bool tensor_per_channel = tensor->exponent.is_per_channel();

    if (this_per_channel || tensor_per_channel) {
        if (this->exponent == tensor->exponent && this->dtype == tensor->dtype) {
            tool::copy_memory(this->data, tensor->data, this->get_bytes());
            return true;
        }
        ESP_LOGE("TensorBase::assign",
                 "Per-channel tensor assign failed: exponent or dtype mismatch. "
                 "this->exponent.is_per_channel=%d, tensor->exponent.is_per_channel=%d, "
                 "this->dtype=%s, tensor->dtype=%s",
                 this_per_channel,
                 tensor_per_channel,
                 dtype_to_string(this->dtype),
                 dtype_to_string(tensor->dtype));
        return false;
    }

    if (this->exponent == tensor->exponent && this->dtype == tensor->dtype) {
        tool::copy_memory(this->data, tensor->data, this->get_bytes());
    } else if (tensor->dtype == DATA_TYPE_FLOAT) {
        float *src_data = (float *)tensor->data;
        float inv_scale = DL_RESCALE(this->exponent);

        if (this->dtype == DATA_TYPE_INT8) {
            int8_t *data = (int8_t *)this->data;
            for (int i = 0; i < this->get_size(); i++) {
                data[i] = quantize<int8_t>(src_data[i], inv_scale);
            }
        } else if (this->dtype == DATA_TYPE_INT16) {
            int16_t *data = (int16_t *)this->data;
            for (int i = 0; i < this->get_size(); i++) {
                data[i] = quantize<int16_t>(src_data[i], inv_scale);
            }
        } else {
            return false;
        }
    } else if (tensor->dtype == DATA_TYPE_DOUBLE) {
        double *src_data = (double *)tensor->data;
        float inv_scale = DL_RESCALE(this->exponent);

        if (this->dtype == DATA_TYPE_INT8) {
            int8_t *data = (int8_t *)this->data;
            for (int i = 0; i < this->get_size(); i++) {
                data[i] = quantize<int8_t, double>(src_data[i], inv_scale);
            }
        } else if (this->dtype == DATA_TYPE_INT16) {
            int16_t *data = (int16_t *)this->data;
            for (int i = 0; i < this->get_size(); i++) {
                data[i] = quantize<int16_t, double>(src_data[i], inv_scale);
            }
        } else {
            return false;
        }
    } else if (this->dtype == DATA_TYPE_FLOAT) {
        float *data = (float *)this->data;
        float scale = DL_SCALE(tensor->exponent);

        if (tensor->dtype == DATA_TYPE_INT8 || tensor->dtype == DATA_TYPE_UINT8) {
            int8_t *src_data = (int8_t *)tensor->data;
            for (int i = 0; i < this->get_size(); i++) {
                data[i] = dequantize(src_data[i], scale);
            }
        } else if (tensor->dtype == DATA_TYPE_INT16 || tensor->dtype == DATA_TYPE_UINT16) {
            int16_t *src_data = (int16_t *)tensor->data;
            for (int i = 0; i < this->get_size(); i++) {
                data[i] = dequantize(src_data[i], scale);
            }
        } else {
            return false;
        }
    } else if (this->dtype == DATA_TYPE_DOUBLE) {
        double *data = (double *)this->data;
        float scale = DL_SCALE(tensor->exponent);

        if (tensor->dtype == DATA_TYPE_INT8 || tensor->dtype == DATA_TYPE_UINT8) {
            int8_t *src_data = (int8_t *)tensor->data;
            for (int i = 0; i < this->get_size(); i++) {
                data[i] = dequantize<int8_t, double>(src_data[i], scale);
            }
        } else if (tensor->dtype == DATA_TYPE_INT16 || tensor->dtype == DATA_TYPE_UINT16) {
            int16_t *src_data = (int16_t *)tensor->data;
            for (int i = 0; i < this->get_size(); i++) {
                data[i] = dequantize<int16_t, double>(src_data[i], scale);
            }
        } else {
            return false;
        }
    } else if (this->exponent != tensor->exponent || this->dtype != tensor->dtype) {
        // quantize(dequtize())
        if (this->exponent == tensor->exponent) {
            if (this->dtype == DATA_TYPE_INT8 && tensor->dtype == DATA_TYPE_INT16) {
                int16_t *src_data = static_cast<int16_t *>(tensor->data);
                int8_t *data = static_cast<int8_t *>(this->data);
                for (int i = 0; i < this->get_size(); i++) {
                    data[i] = static_cast<int8_t>(DL_CLIP(src_data[i], DL_QUANT8_MIN, DL_QUANT8_MAX));
                }
            } else if (this->dtype == DATA_TYPE_INT16 && tensor->dtype == DATA_TYPE_INT8) {
                int8_t *src_data = static_cast<int8_t *>(tensor->data);
                int16_t *data = static_cast<int16_t *>(this->data);
                for (int i = 0; i < this->get_size(); i++) {
                    data[i] = static_cast<int16_t>(src_data[i]);
                }
            } else {
                return false;
            }
        } else {
#if CONFIG_PIE_V1_BOOST || CONFIG_PIE_V2_BOOST
            if (this->get_size() > 50) {
                std::vector<base::requantizeArgsType> args =
                    base::get_requantize_operation_args(this, tensor, RUNTIME_MODE_SINGLE_CORE);
                if (!(reinterpret_cast<uintptr_t>(args[0].input_element) & 0xf) &&
                    !(reinterpret_cast<uintptr_t>(args[0].output_element) & 0xf)) {
                    if (this->dtype == DATA_TYPE_INT8 && tensor->dtype == DATA_TYPE_INT8) {
                        base::requantize_linear<int8_t, int8_t>(&args[0]);
                        return true;
                    } else if (this->dtype == DATA_TYPE_INT8 && tensor->dtype == DATA_TYPE_INT16) {
                        base::requantize_linear<int8_t, int16_t>(&args[0]);
                        return true;
                    } else if (this->dtype == DATA_TYPE_INT16 && tensor->dtype == DATA_TYPE_INT16 &&
                               !(args[0].output_shift == 0 && args[0].output_scale > 0x4000)) {
                        base::requantize_linear<int16_t, int16_t>(&args[0]);
                        return true;
                    } else if (this->dtype == DATA_TYPE_INT16 && tensor->dtype == DATA_TYPE_INT8) {
                        base::requantize_linear<int16_t, int8_t>(&args[0]);
                        return true;
                    }
                }
            }
#endif

            float src_scale = DL_SCALE(tensor->exponent);
            float inv_scale = 1.0 / (DL_SCALE(this->exponent));

            if (this->dtype == DATA_TYPE_INT8 && tensor->dtype == DATA_TYPE_INT8) {
                int8_t *src_data = static_cast<int8_t *>(tensor->data);
                int8_t *data = static_cast<int8_t *>(this->data);
                for (int i = 0; i < this->get_size(); i++) {
                    float tmp = dequantize(src_data[i], src_scale);
                    data[i] = quantize<int8_t>(tmp, inv_scale);
                }
            } else if (this->dtype == DATA_TYPE_INT16 && tensor->dtype == DATA_TYPE_INT16) {
                int16_t *src_data = static_cast<int16_t *>(tensor->data);
                int16_t *data = static_cast<int16_t *>(this->data);
                for (int i = 0; i < this->get_size(); i++) {
                    float tmp = dequantize(src_data[i], src_scale);
                    data[i] = quantize<int16_t>(tmp, inv_scale);
                }
            } else if (this->dtype == DATA_TYPE_INT8 && tensor->dtype == DATA_TYPE_INT16) {
                int16_t *src_data = static_cast<int16_t *>(tensor->data);
                int8_t *data = static_cast<int8_t *>(this->data);
                for (int i = 0; i < this->get_size(); i++) {
                    float tmp = dequantize(src_data[i], src_scale);
                    data[i] = quantize<int8_t>(tmp, inv_scale);
                }
            } else if (this->dtype == DATA_TYPE_INT16 && tensor->dtype == DATA_TYPE_INT8) {
                int8_t *src_data = static_cast<int8_t *>(tensor->data);
                int16_t *data = static_cast<int16_t *>(this->data);
                for (int i = 0; i < this->get_size(); i++) {
                    float tmp = dequantize(src_data[i], src_scale);
                    data[i] = quantize<int16_t>(tmp, inv_scale);
                }
            } else {
                return false;
            }
        }
    } else {
        return false;
    }
    return true;
}

bool TensorBase::assign(std::vector<int> shape, const void *element, int exponent, dtype_t dtype)
{
    TensorBase tensor(shape, element, exponent, dtype, false);
    return this->assign(&tensor);
}

TensorBase &TensorBase::set_element_ptr(void *data)
{
    this->data = data;

    return *this;
}

TensorBase &TensorBase::set_shape(const std::vector<int> shape)
{
    if (shape.size() == 0) {
        this->size = 1;
        this->shape = shape;
        this->axis_offset = {};
        return *this;
    }

    assert(shape.size() > 0);
    this->size = 1;
    for (int i = 0; i < shape.size(); ++i) {
        assert(shape[i] >= 1);
        this->size *= shape[i];
    }
    this->shape = shape;

    std::vector<int> axis_offset(this->shape.size(), 1);
    for (int i = shape.size() - 2; i > -1; --i) {
        axis_offset[i] = axis_offset[i + 1] * this->shape[i + 1];
    }
    this->axis_offset = axis_offset;
    return *this;
}

size_t TensorBase::set_preload_addr(void *addr, size_t size)
{
    size_t aligned_bytes = this->get_aligned_bytes();
    if (addr && size >= aligned_bytes) {
        this->cache = addr;
        return aligned_bytes;
    }
    this->cache = nullptr;
    return 0;
}

void TensorBase::reset_bias_layout(quant_type_t op_quant_type, bool is_depthwise)
{
    // The bias needs to be quantized to 32 bits.
    if (op_quant_type == QUANT_TYPE_SYMM_8BIT) {
        assert(this->dtype == DATA_TYPE_INT32);
    } else {
        if (this->dtype != DATA_TYPE_INT64) {
            ESP_LOGE(__FUNCTION__,
                     "The quantization bit width of the bias has been modified. Please update esp-ppq and then "
                     "re-quantize the model.");
        }
        assert(this->dtype == DATA_TYPE_INT64);
    }

#if CONFIG_IDF_TARGET_ESP32S3
    // Reset bias layout for esp32s3
    if (op_quant_type == QUANT_TYPE_SYMM_8BIT) {
        // 0x000AAAAA000BBBBB ==> 0xAAAAABBBBB
        size_t dtype_bytes = 1;
        size_t align = 16 / dtype_bytes;
        size_t data_num = this->get_size();
        size_t align_num = ((size_t)(data_num / align)) * align;
        size_t remain_num = data_num - align_num;
        if (is_depthwise) {
            align_num = data_num;
            remain_num = 0;
        }
        // QACC, EE.LD.QACC_L.L.128.IP / EE.LD.QACC_H.L.128.IP requires 16-byte address alignment.
        //      When the bias is stored with a size of 4 bytes, the address is exactly 16-byte aligned
        //      when used in EE.LD.QACC_H.L.128.IP, so the size of the aligned portion of memory here
        //      is calculated based on 4 bytes.
        // ACCX, EE.LD.ACCX.IP requires 8-byte address alignment.
        size_t memory_size_needed = align_num * 4 + remain_num * 8;
        // get the aligned size
        memory_size_needed = memory_size_needed % align == 0 ? memory_size_needed
                                                             : memory_size_needed + align - memory_size_needed % align;
        int32_t *src_ptr = static_cast<int32_t *>(this->data);
        int8_t *dst_ptr = static_cast<int8_t *>(tool::calloc_aligned(memory_size_needed, dtype_bytes, this->caps));
        assert(dst_ptr);
        int8_t *dst_ptr_head = dst_ptr;

        // 0x000AAAAA000BBBBB ==> 0xAAAAABBBBB
        int i = 0;
        for (; i < align_num; i++) {
            int32_t src_data = src_ptr[i] & 0xfffff;
            if (i & 1) {
                int8_t src_least_4bit = src_data & 0xf;
                (*(--dst_ptr_head)) |= (src_least_4bit << 4);
                src_data >>= 4;
            } else {
                *dst_ptr_head = src_data & 0xff;
                src_data >>= 8;
            }
            dst_ptr_head++;
            *(reinterpret_cast<int16_t *>(dst_ptr_head)) = static_cast<int16_t>(src_data);
            dst_ptr_head += 2;

            // Move to the 16-byte memory address alignment.
            if (((i + 1) % (align >> 1) == 0) && (reinterpret_cast<uintptr_t>(dst_ptr_head) & 0xf)) {
                dst_ptr_head = dst_ptr_head + 16 - (reinterpret_cast<uintptr_t>(dst_ptr_head) & 0xf);
            }
        }

        for (int j = 0; j < remain_num; j++, i++) {
            (reinterpret_cast<int64_t *>(dst_ptr_head))[j] = src_ptr[i];
        }

        if (this->auto_free) {
            heap_caps_free(this->data);
        }
        this->data = dst_ptr;
        this->auto_free = true;

    } else if (op_quant_type == QUANT_TYPE_SYMM_16BIT || op_quant_type == QUANT_TYPE_SYMM_W8A16) {
        // 0x000000AAAAAAAAAA000000BBBBBBBBBB ==> 0xAAAAAAAAAABBBBBBBBBB
        size_t dtype_bytes = 2;
        size_t align = 16 / dtype_bytes;
        size_t data_num = this->get_size();
        size_t align_num = ((size_t)(data_num / align)) * align;
        size_t remain_num = data_num - align_num;
        if (is_depthwise) {
            align_num = data_num;
            remain_num = 0;
        }

        int64_t *src_ptr = static_cast<int64_t *>(this->data);
        int8_t *dst_ptr = static_cast<int8_t *>(tool::calloc_aligned(data_num, this->get_dtype_bytes(), this->caps));
        int8_t *dst_ptr_head = dst_ptr;
        // 0x000000AAAAAAAAAA000000BBBBBBBBBB ==> 0xAAAAAAAAAABBBBBBBBBB
        for (int i = 0; i < align_num; i++) {
            dl::tool::copy_memory(dst_ptr, src_ptr, 5);
            dst_ptr += 5;
            src_ptr++;

            // Move to the 16-byte memory address alignment.
            if (((i + 1) % (align >> 1) == 0) && (reinterpret_cast<uintptr_t>(dst_ptr) & 0xf)) {
                dst_ptr = dst_ptr + 16 - (reinterpret_cast<uintptr_t>(dst_ptr) & 0xf);
            }
        }

        for (int j = 0; j < remain_num; j++) {
            (reinterpret_cast<int64_t *>(dst_ptr))[j] = src_ptr[j];
        }

        if (this->auto_free) {
            heap_caps_free(this->data);
        }

        this->data = dst_ptr_head;
        this->auto_free = true;
    }
#endif
}

void TensorBase::push(TensorBase *new_tensor, int dim)
{
    if (dim < 0 || dim >= this->shape.size()) {
        ESP_LOGE(__FUNCTION__, "The dim is out of range.");
        return;
    }

    if (this->dtype != new_tensor->dtype) {
        ESP_LOGE(__FUNCTION__, "this->dtype != new_tensor->dtype");
        return;
    }

    if (new_tensor->shape[dim] > this->shape[dim]) {
        ESP_LOGE(__FUNCTION__,
                 "The time series dimension size of new tensor "
                 "is greater than that of the current tensor.");
        return;
    }

    // NCW or NWC
    int loop_num = 1;
    int move_chunk_size = 1;
    int copy_chunk_size = 1;
    for (int i = this->shape.size() - 1; i >= 0; i--) {
        if (i != dim) {
            assert(this->shape[i] == new_tensor->shape[i]);
        }

        if (i < dim) {
            loop_num *= this->shape[i];
        } else if (i == dim) {
            move_chunk_size *= (this->shape[i] - new_tensor->shape[i]);
            copy_chunk_size *= new_tensor->shape[i];
        } else if (i > dim) {
            move_chunk_size *= this->shape[i];       // The move size of the current tensor
            copy_chunk_size *= new_tensor->shape[i]; // The copy size of the new tensor
        }
    }

    // Since the old one is removed to free up space for the new one, their sizes are equal.
    int move_offset = copy_chunk_size;
    int current_loop_stride = move_chunk_size + copy_chunk_size;

    for (int i = 0; i < loop_num; i++) {
        if (this->dtype == DATA_TYPE_INT8) {
            // move chunk
            tool::copy_memory(get_element_ptr<int8_t>() + i * current_loop_stride,
                              get_element_ptr<int8_t>() + i * current_loop_stride + move_offset,
                              move_chunk_size);
            // copy new tensor
            tool::copy_memory(get_element_ptr<int8_t>() + i * current_loop_stride + move_chunk_size,
                              new_tensor->get_element_ptr<int8_t>() + i * copy_chunk_size,
                              copy_chunk_size);
        } else if (this->dtype == DATA_TYPE_INT16) {
            // move chunk
            tool::copy_memory(get_element_ptr<int16_t>() + i * current_loop_stride,
                              get_element_ptr<int16_t>() + i * current_loop_stride + move_offset,
                              move_chunk_size);
            // copy new tensor
            tool::copy_memory(get_element_ptr<int16_t>() + i * current_loop_stride + move_chunk_size,
                              new_tensor->get_element_ptr<int16_t>() + i * copy_chunk_size,
                              copy_chunk_size);
        } else {
            ESP_LOGE(__FUNCTION__, "Don't support dtype: %d", this->dtype);
        }
    }
    return;
}

void TensorBase::print(bool print_data)
{
    ESP_LOGI(__FUNCTION__,
             "shape: %s, dtype: %s, exponent: %d, auto_free: %d, data: %p",
             vector_to_string(get_shape()).c_str(),
             dtype_to_string(get_dtype()),
             (int)this->exponent,
             this->auto_free,
             this->data);

    if (this->data && print_data) {
        ESP_LOGI(__FUNCTION__, "The data of TensorBase is:");
        if (get_dtype() == DATA_TYPE_FLOAT) {
            for (int i = 0; i < get_size(); i++) {
                printf("%f, ", get_element<float>(i));
                if ((i + 1) % 16 == 0) {
                    printf("\n");
                }
            }
        } else if (get_dtype() == DATA_TYPE_DOUBLE) {
            for (int i = 0; i < get_size(); i++) {
                printf("%f, ", get_element<double>(i));
                if ((i + 1) % 16 == 0) {
                    printf("\n");
                }
            }
        } else if (get_dtype() == DATA_TYPE_INT8) {
            for (int i = 0; i < get_size(); i++) {
                printf("%d, ", get_element<int8_t>(i));
                if ((i + 1) % 16 == 0) {
                    printf("\n");
                }
            }
        } else if (get_dtype() == DATA_TYPE_INT16) {
            for (int i = 0; i < get_size(); i++) {
                printf("%d, ", get_element<int16_t>(i));
                if ((i + 1) % 16 == 0) {
                    printf("\n");
                }
            }
        } else if (get_dtype() == DATA_TYPE_BOOL) {
            for (int i = 0; i < get_size(); i++) {
                printf("%d, ", get_element<bool>(i));
                if ((i + 1) % 16 == 0) {
                    printf("\n");
                }
            }
        } else {
            ESP_LOGE(__FUNCTION__, "The dtype don't support now!");
        }
        printf("\n");
    }
}

TensorBase *TensorBase::reshape(std::vector<int> shape)
{
    int size_gt = this->get_size();
    int index = -1;
    for (int i = 0; i < shape.size(); ++i) {
        if (shape[i] == -1) {
            assert(index == -1);
            index = i;
        } else {
            assert(shape[i] > 0);
        }
    }
    int size = 1;
    if (index == -1) {
        for (int i = 0; i < shape.size(); ++i) {
            size *= shape[i];
        }
        assert(size == size_gt);
        this->set_shape(shape);
    } else {
        for (int i = 0; i < shape.size(); ++i) {
            if (shape[i] > 0) {
                size *= shape[i];
            }
        }
        assert((size_gt % size) == 0);
        shape[index] = size_gt / size;
        this->set_shape(shape);
    }
    return this;
}

#if CONFIG_PIE_V1_BOOST || CONFIG_PIE_V2_BOOST
static bool is_compact_row_major(const std::vector<int> &shape, const std::vector<int> &axis_offset)
{
    if (shape.empty() || axis_offset.size() != shape.size()) {
        return false;
    }
    if (axis_offset.back() != 1) {
        return false;
    }
    int off = 1;
    for (int i = (int)shape.size() - 2; i >= 0; --i) {
        off *= shape[i + 1];
        if (axis_offset[i] != off) {
            return false;
        }
    }
    return true;
}

// Fold size-1 dims, then match leading identity + two-group swap + trailing inner block.
// Result is `batch` independent transposes of an N×M grid of K-element blocks.
static bool analyze_transpose_2d(
    const std::vector<int> &shape, const std::vector<int> &perm, int &batch, int &N, int &M, int &K)
{
    const int dims = (int)shape.size();
    if (dims == 0 || (int)perm.size() != dims) {
        return false;
    }

    std::vector<int> old_to_new(dims, -1);
    std::vector<int> sq_shape;
    sq_shape.reserve(dims);
    for (int i = 0; i < dims; ++i) {
        if (shape[i] > 1) {
            old_to_new[i] = (int)sq_shape.size();
            sq_shape.push_back(shape[i]);
        }
    }

    std::vector<int> sq_perm;
    sq_perm.reserve(sq_shape.size());
    for (int i = 0; i < dims; ++i) {
        int mapped = old_to_new[perm[i]];
        if (mapped >= 0) {
            sq_perm.push_back(mapped);
        }
    }
    if (sq_perm.size() != sq_shape.size()) {
        return false;
    }

    const int nd = (int)sq_shape.size();
    if (nd <= 1) {
        batch = 1;
        N = nd == 0 ? 1 : sq_shape[0];
        M = 1;
        K = 1;
        return true;
    }

    int lead = 0;
    while (lead < nd && sq_perm[lead] == lead) {
        ++lead;
    }
    batch = 1;
    for (int i = 0; i < lead; ++i) {
        batch *= sq_shape[i];
    }

    const int rem = nd - lead;
    int suffix = 0;
    while (suffix < rem && sq_perm[nd - 1 - suffix] == nd - 1 - suffix) {
        ++suffix;
    }
    const int inner_start = rem - suffix;

    auto prod_range = [&](int begin, int end) {
        int p = 1;
        for (int i = begin; i < end; ++i) {
            p *= sq_shape[i];
        }
        return p;
    };

    K = suffix == 0 ? 1 : prod_range(lead + inner_start, nd);
    if (inner_start <= 1) {
        N = inner_start == 0 ? 1 : sq_shape[lead];
        M = 1;
        return true;
    }

    int split = -1;
    for (int s = 1; s < inner_start; ++s) {
        bool ok = true;
        int expect = s;
        for (int i = 0; i < inner_start && ok; ++i) {
            if (sq_perm[lead + i] - lead != expect) {
                ok = false;
            }
            ++expect;
            if (expect == inner_start) {
                expect = 0;
            }
        }
        if (ok) {
            split = s;
            break;
        }
    }
    if (split < 0) {
        return false;
    }

    N = prod_range(lead, lead + split);
    M = prod_range(lead + split, lead + inner_start);
    return N >= 1 && M >= 1 && K >= 1;
}

template <typename T>
static bool try_simd_transpose(T *output,
                               const T *input,
                               const std::vector<int> &input_shape,
                               const std::vector<int> &input_axis_offset,
                               const std::vector<int> &perm)
{
    int batch = 0, N = 0, M = 0, K = 0;
    if (!analyze_transpose_2d(input_shape, perm, batch, N, M, K)) {
        return false;
    }

    if (!is_compact_row_major(input_shape, input_axis_offset)) {
        return false;
    }

    const size_t plane = (size_t)N * (size_t)M * (size_t)K;
    const size_t total_bytes = (size_t)batch * plane * sizeof(T);
    if (N == 1 || M == 1) {
        memcpy(output, input, total_bytes);
        return true;
    }
    if ((reinterpret_cast<uintptr_t>(output) | reinterpret_cast<uintptr_t>(input)) & 0xf) {
        return false;
    }

    if constexpr (std::is_same<T, int8_t>::value) {
        bool partial = false;
#if CONFIG_PIE_V2_BOOST && CONFIG_IDF_TARGET_ESP32P4
        const uintptr_t src_begin = reinterpret_cast<uintptr_t>(input);
        const uintptr_t dst_begin = reinterpret_cast<uintptr_t>(output);
        const bool separate =
            uint64_t(src_begin) + total_bytes <= dst_begin || uint64_t(dst_begin) + total_bytes <= src_begin;
        partial = K == 1 && N >= 8 && M >= 16 && plane >= 1024 && ((N & 7) || (M & 15)) && separate;
#endif
        if (K == 1 && (((N % 8 == 0) && (M % 16 == 0)) || partial)) {
            for (int b = 0; b < batch; ++b) {
#if CONFIG_PIE_V2_BOOST
                if (partial)
                    dl_esp32p4_cfg_misalign(HW_MISALIGN, HW_MISALIGN);
                // The kernel writes complete blocks and keeps the original row strides.
                dl_esp32p4_s8_transpose(output + b * plane, input + b * plane, N, M);
                if (partial) {
                    dl_esp32p4_cfg_misalign(FORCE_ALIGN, FORCE_ALIGN);
                    const int rows = N & -8, columns = M & -16;
                    T *dst = output + b * plane;
                    const T *src = input + b * plane;
                    for (int n = 0; n < rows; ++n)
                        for (int m = columns; m < M; ++m) dst[m * N + n] = src[n * M + m];
                    for (int n = rows; n < N; ++n)
                        for (int m = 0; m < M; ++m) dst[m * N + n] = src[n * M + m];
                }
#else
                dl_tie728_s8_transpose(output + b * plane, input + b * plane, N, M);
#endif
            }
            return true;
        }
        if (K > 1) {
            for (int b = 0; b < batch; ++b) {
#if CONFIG_PIE_V2_BOOST
                dl_esp32p4_block_transpose(output + b * plane, input + b * plane, N, M, K);
#else
                dl_tie728_block_transpose(output + b * plane, input + b * plane, N, M, K);
#endif
            }
            return true;
        }
    } else if constexpr (std::is_same<T, int16_t>::value) {
        if (K == 1 && (N % 8 == 0) && (M % 8 == 0)) {
            for (int b = 0; b < batch; ++b) {
#if CONFIG_PIE_V2_BOOST
                dl_esp32p4_s16_transpose(output + b * plane, input + b * plane, N, M);
#else
                dl_tie728_s16_transpose(output + b * plane, input + b * plane, N, M);
#endif
            }
            return true;
        }
        if (K > 1) {
            for (int b = 0; b < batch; ++b) {
#if CONFIG_PIE_V2_BOOST
                dl_esp32p4_s16_block_transpose(output + b * plane, input + b * plane, N, M, K);
#else
                dl_tie728_s16_block_transpose(output + b * plane, input + b * plane, N, M, K);
#endif
            }
            return true;
        }
    }
    return false;
}
#endif

static constexpr int kTransposeMaxDims = 16;

// Last-dim memcpy + pointer walking. Trailing identity axes that are packed in
// the input are copied as one contiguous block; remaining axes step pointers.
template <typename T>
static void transpose_memcpy_fallback(T *output,
                                      const T *input,
                                      const std::vector<int> &in_shape,
                                      const std::vector<int> &in_off,
                                      const std::vector<int> &out_off,
                                      const std::vector<int> &perm)
{
    const int dims = (int)perm.size();
    if (dims <= 0 || dims > kTransposeMaxDims) {
        return;
    }

    int suffix = 0;
    int copy_elems = 1;
    if (!in_off.empty() && in_off.back() == 1) {
        int packed = 1;
        for (int i = dims - 1; i >= 0; --i) {
            if (perm[i] != i || in_off[i] != packed) {
                break;
            }
            packed *= in_shape[i];
            suffix++;
        }
        if (suffix > 0) {
            copy_elems = packed;
        }
    }

    const int outer_dims = dims - suffix;
    const size_t copy_bytes = (size_t)copy_elems * sizeof(T);
    if (outer_dims <= 0) {
        memcpy(output, input, copy_bytes);
        return;
    }

    int out_step[kTransposeMaxDims] = {};
    for (int o = 0; o < dims; ++o) {
        const int src_ax = perm[o];
        if (src_ax < outer_dims) {
            out_step[src_ax] = out_off[o];
        }
    }

    int coords[kTransposeMaxDims] = {};
    const T *src_ptr = input;
    T *dst_ptr = output;
    while (true) {
        if (copy_elems == 1) {
            *dst_ptr = *src_ptr;
        } else {
            memcpy(dst_ptr, src_ptr, copy_bytes);
        }

        int d = outer_dims - 1;
        for (; d >= 0; --d) {
            coords[d]++;
            src_ptr += in_off[d];
            dst_ptr += out_step[d];
            if (coords[d] < in_shape[d]) {
                break;
            }
            src_ptr -= in_off[d] * in_shape[d];
            dst_ptr -= out_step[d] * in_shape[d];
            coords[d] = 0;
        }
        if (d < 0) {
            break;
        }
    }
}

template <typename T>
TensorBase *TensorBase::transpose(T *input_element,
                                  std::vector<int> &input_shape,
                                  std::vector<int> &input_axis_offset,
                                  std::vector<int> &perm)
{
    if (shape.size() == 0 || input_shape.size() == 0) {
        ((T *)this->get_element_ptr())[0] = input_element[0];
        return this;
    }

    if (perm.size() == 0) {
        for (int i = shape.size() - 1; i >= 0; i--) {
            perm.push_back(i);
        }
    }
    int dims = perm.size();

    for (int i = 0; i < dims; ++i) {
        if (perm[i] < 0)
            perm[i] = dims + perm[i];
        this->shape[i] = input_shape[perm[i]];
    }

    this->axis_offset[dims - 1] = 1;
    for (int i = dims - 2; i > -1; --i) {
        this->axis_offset[i] = this->axis_offset[i + 1] * this->shape[i + 1];
    }
    T *output_element = (T *)this->get_element_ptr();

#if CONFIG_PIE_V1_BOOST || CONFIG_PIE_V2_BOOST
    if constexpr (std::is_same<T, int8_t>::value || std::is_same<T, int16_t>::value) {
        if (try_simd_transpose(output_element, input_element, input_shape, input_axis_offset, perm)) {
            return this;
        }
    }
#endif

    if (dims <= kTransposeMaxDims) {
        transpose_memcpy_fallback(
            output_element, input_element, input_shape, input_axis_offset, this->axis_offset, perm);
    } else {
        std::vector<int> index_old(dims, 0);
        for (int i = 0; i < this->size; ++i) {
            int dim_div_value = i;
            int index_new = 0;
            for (int j = dims - 1; j > -1; --j) {
                index_old[j] = dim_div_value % input_shape[j];
                dim_div_value /= input_shape[j];
            }
            for (int j = dims - 1; j > -1; --j) {
                index_new += index_old[perm[j]] * this->axis_offset[j];
            }
            output_element[index_new] = input_element[i];
        }
    }

    return this;
}

TensorBase *TensorBase::transpose(TensorBase *input, std::vector<int> perm)
{
    assert(this->get_size() == input->get_size());
    assert(this->dtype == input->dtype);

    if (this->dtype == DATA_TYPE_INT8) {
        transpose<int8_t>((int8_t *)input->get_element_ptr(), input->shape, input->axis_offset, perm);
    } else if (this->dtype == DATA_TYPE_UINT8) {
        transpose<uint8_t>((uint8_t *)input->get_element_ptr(), input->shape, input->axis_offset, perm);
    } else if (this->dtype == DATA_TYPE_INT16) {
        transpose<int16_t>((int16_t *)input->get_element_ptr(), input->shape, input->axis_offset, perm);
    } else if (this->dtype == DATA_TYPE_INT32) {
        transpose<int32_t>((int32_t *)input->get_element_ptr(), input->shape, input->axis_offset, perm);
    } else if (this->dtype == DATA_TYPE_UINT16) {
        transpose<uint16_t>((uint16_t *)input->get_element_ptr(), input->shape, input->axis_offset, perm);
    } else if (this->dtype == DATA_TYPE_INT32) {
        transpose<uint32_t>((uint32_t *)input->get_element_ptr(), input->shape, input->axis_offset, perm);
    } else if (this->dtype == DATA_TYPE_FLOAT) {
        transpose<float>((float *)input->get_element_ptr(), input->shape, input->axis_offset, perm);
    }

    return this;
}

int TensorBase::get_element_index(const std::vector<int> &axis_index)
{
    int element_index = 0;
    for (int i = 0; i < axis_index.size(); i++) {
        element_index += axis_index[i] * this->axis_offset[i];
    }
    return element_index;
}

std::vector<int> TensorBase::get_element_coordinates(int index)
{
    int ndim = this->shape.size();
    std::vector<int> coords(ndim);
    for (int k = 0; k < ndim; ++k) {
        coords[k] = index / this->axis_offset[k];
        index %= this->axis_offset[k];
    }
    return coords;
}

template <typename T>
T TensorBase::get_element(int index)
{
    if (index < 0) {
        index += this->size;
    }

    return ((T *)this->data)[index];
}
template int8_t TensorBase::get_element<int8_t>(int index);
template uint8_t TensorBase::get_element<uint8_t>(int index);
template int16_t TensorBase::get_element<int16_t>(int index);
template uint16_t TensorBase::get_element<uint16_t>(int index);
template int32_t TensorBase::get_element<int32_t>(int index);
template uint32_t TensorBase::get_element<uint32_t>(int index);
template int64_t TensorBase::get_element<int64_t>(int index);
template float TensorBase::get_element<float>(int index);

template <typename T>
T TensorBase::get_element(const std::vector<int> &axis_index)
{
    int index = this->get_element_index(axis_index);
    return ((T *)this->data)[index];
}
template int8_t TensorBase::get_element<int8_t>(const std::vector<int> &axis_index);
template uint8_t TensorBase::get_element<uint8_t>(const std::vector<int> &axis_index);
template int16_t TensorBase::get_element<int16_t>(const std::vector<int> &axis_index);
template uint16_t TensorBase::get_element<uint16_t>(const std::vector<int> &axis_index);
template int32_t TensorBase::get_element<int32_t>(const std::vector<int> &axis_index);
template uint32_t TensorBase::get_element<uint32_t>(const std::vector<int> &axis_index);
template float TensorBase::get_element<float>(const std::vector<int> &axis_index);

template <typename T>
bool TensorBase::compare_elements(const T *gt_elements, float epsilon, bool verbose)
{
    T *elements = (T *)this->get_element_ptr();
    if (elements == gt_elements) {
        return true;
    }

    for (int i = 0; i < this->get_size(); i++) {
        if constexpr (std::is_same_v<T, float>) {
            const bool gt_is_nan = is_nan(gt_elements[i]);
            const bool infer_is_nan = is_nan(elements[i]);
            if (gt_is_nan || infer_is_nan) {
                if (gt_is_nan && infer_is_nan) {
                    continue;
                }
                if (verbose) {
                    ESP_LOGE(__FUNCTION__,
                             "Inconsistent values, ground truth: %.10f, infer: %.10f, epsilon:%.10f",
                             gt_elements[i] * 1.0,
                             elements[i] * 1.0,
                             epsilon);
                    std::vector<int> position = this->get_element_coordinates(i);
                    ESP_LOGE(__FUNCTION__, "The position is: %s", vector_to_string(position).c_str());
                }
                return false;
            }
        }
        if (elements[i] - gt_elements[i] > epsilon || elements[i] - gt_elements[i] < -epsilon) {
            if (verbose) {
                ESP_LOGE(__FUNCTION__,
                         "Inconsistent values, ground truth: %.10f, infer: %.10f, epsilon:%.10f",
                         gt_elements[i] * 1.0,
                         elements[i] * 1.0,
                         epsilon);
                std::vector<int> position = this->get_element_coordinates(i);
                ESP_LOGE(__FUNCTION__, "The position is: %s", vector_to_string(position).c_str());
            }
            return false;
        }
    }

    return true;
}
template bool TensorBase::compare_elements<int8_t>(const int8_t *gt_elements, float epsilon, bool verbose);
template bool TensorBase::compare_elements<uint8_t>(const uint8_t *gt_elements, float epsilon, bool verbose);
template bool TensorBase::compare_elements<int16_t>(const int16_t *gt_elements, float epsilon, bool verbose);
template bool TensorBase::compare_elements<uint16_t>(const uint16_t *gt_elements, float epsilon, bool verbose);
template bool TensorBase::compare_elements<int32_t>(const int32_t *gt_elements, float epsilon, bool verbose);
template bool TensorBase::compare_elements<uint32_t>(const uint32_t *gt_elements, float epsilon, bool verbose);
template bool TensorBase::compare_elements<float>(const float *gt_elements, float epsilon, bool verbose);
template bool TensorBase::compare_elements<double>(const double *gt_elements, float epsilon, bool verbose);
template bool TensorBase::compare_elements<bool>(const bool *gt_elements, float epsilon, bool verbose);

bool TensorBase::is_same_shape(TensorBase *tensor)
{
    if (this->shape.size() != tensor->shape.size()) {
        return false;
    }
    for (int i = 0; i < this->shape.size(); i++) {
        if (this->shape[i] != tensor->shape[i]) {
            return false;
        }
    }
    return true;
}

bool TensorBase::equal(TensorBase *tensor, float epsilon, bool verbose)
{
    if (tensor == nullptr) {
        return false;
    }

    // compare data type
    dtype_t type1 = this->get_dtype();
    dtype_t type2 = tensor->get_dtype();
    if (type1 != type2) {
        if (verbose) {
            ESP_LOGE(__FUNCTION__, "data type not equal: %s != %s", dtype_to_string(type1), dtype_to_string(type2));
        }
        return false;
    }

    // compare shape
    if (!this->is_same_shape(tensor)) {
        if (verbose) {
            ESP_LOGE(__FUNCTION__,
                     "shape not equal: %s != %s",
                     vector_to_string(this->shape).c_str(),
                     vector_to_string(tensor->shape).c_str());
        }
        return false;
    }

    // compare tensor element
    if (this->exponent != tensor->exponent) {
        if (verbose) {
            ESP_LOGE(__FUNCTION__, "exponent not equal: %d != %d", (int)this->exponent, (int)tensor->exponent);
        }
        return false;
    }

    if (verbose || epsilon > 0) {
        if (type1 == DATA_TYPE_INT8) {
            return this->compare_elements<int8_t>((int8_t *)tensor->get_element_ptr(), epsilon, verbose);
        } else if (type1 == DATA_TYPE_INT16) {
            return this->compare_elements<int16_t>((int16_t *)tensor->get_element_ptr(), epsilon, verbose);
        } else if (type1 == DATA_TYPE_FLOAT) {
            return this->compare_elements<float>((float *)tensor->get_element_ptr(), epsilon, verbose);
        } else if (type1 == DATA_TYPE_UINT8) {
            return this->compare_elements<uint8_t>((uint8_t *)tensor->get_element_ptr(), epsilon, verbose);
        } else if (type1 == DATA_TYPE_UINT16) {
            return this->compare_elements<uint16_t>((uint16_t *)tensor->get_element_ptr(), epsilon, verbose);
        } else if (type1 == DATA_TYPE_INT32) {
            return this->compare_elements<int32_t>((int32_t *)tensor->get_element_ptr(), epsilon, verbose);
        } else if (type1 == DATA_TYPE_UINT32) {
            return this->compare_elements<uint32_t>((uint32_t *)tensor->get_element_ptr(), epsilon, verbose);
        } else if (type1 == DATA_TYPE_DOUBLE) {
            return this->compare_elements<double>((double *)tensor->get_element_ptr(), epsilon, verbose);
        } else if (type1 == DATA_TYPE_BOOL) {
            return this->compare_elements<bool>((bool *)tensor->get_element_ptr(), epsilon, verbose);
        }
    } else {
        return (memcmp(this->get_element_ptr(), tensor->get_element_ptr(), this->get_bytes()) == 0);
    }

    return false;
}

template <typename T>
void _flip(TensorBase *input, const std::vector<int> &axes)
{
    if (axes.empty()) {
        return;
    }
    T *input_element = (T *)input->get_element_ptr();

    for (int i = 0; i < input->get_size(); ++i) {
        // Compute original coordinates
        std::vector<int> coords = input->get_element_coordinates(i);

        // Flip coordinates
        for (int axis : axes) {
            coords[axis] = input->shape[axis] - 1 - coords[axis];
        }

        // Compute flipped index
        int j = input->get_element_index(coords);

        // Swap elements if needed
        if (i < j) {
            T temp = input_element[i];
            input_element[i] = input_element[j];
            input_element[j] = temp;
        }
    }
}

template <typename T>
void _slice(TensorBase *input,
            TensorBase *output,
            const std::vector<int> &start,
            const std::vector<int> &end,
            const std::vector<int> &axes,
            const std::vector<int> &step)
{
    T *input_element = input->get_element_ptr<T>();
    T *output_element = output->get_element_ptr<T>();
    std::vector<int> input_shape = input->get_shape();
    int dims = input_shape.size();

    if (dims == 0) {
        output_element[0] = input_element[0];
        return;
    }

    std::vector<int> loop_start(dims, 0);
    std::vector<int> loop_end = input_shape;
    std::vector<int> loop_step(dims, 1);
    std::vector<int> flipped;

    int last_axis = start.size() - 1;
    for (int i = 0; i < start.size(); i++) {
        int axis = i;
        int step_i = 1;
        int start_i = start[i];
        int end_i = end[i];
        if (!axes.empty()) {
            axis = (axes[i] < 0) ? (axes[i] + dims) : axes[i];
            if (axis > last_axis) {
                last_axis = axis;
            }
        }
        if (!step.empty()) {
            step_i = step[i];
        }
        if (step_i < 0) {
            flipped.push_back(axis);
            start_i = -start_i - 1;
            end_i = -end_i - 1;
            step_i = -step_i;
        }

        if (end_i > input_shape[axis]) {
            end_i = input_shape[axis];
        }

        loop_start[axis] = start_i < 0 ? (start_i + input_shape[axis]) : (start_i % (input_shape[axis] + 1));
        loop_end[axis] = end_i < 0 ? (end_i + input_shape[axis]) : (end_i % (input_shape[axis] + 1));
        loop_step[axis] = step_i;
        assert(loop_start[axis] < loop_end[axis]);
    }
    // contiguous_block_size: tail after last_axis (step always 1, safe for copy_memory).
    // min_offset: includes last_axis range — only valid for copy_memory when step==1.
    int contiguous_block_size = 1;
    for (int i = last_axis + 1; i < dims; i++) {
        contiguous_block_size *= input_shape[i];
    }
    int min_offset = (loop_end[last_axis] - loop_start[last_axis]) * contiguous_block_size;
    T *slice_ptr = nullptr;
    int min_offset_bytes = min_offset * sizeof(T);
    int block_bytes = contiguous_block_size * sizeof(T);

    if (step.empty()) {
        if (dims == 1 || last_axis == 0) {
            slice_ptr = input_element + input->get_element_index(loop_start);
            tool::copy_memory(output_element, slice_ptr, min_offset_bytes);
        } else {
            std::vector<int> loop_index = loop_start;
            while (loop_index[0] < loop_end[0]) {
                slice_ptr = input_element + input->get_element_index(loop_index);
                tool::copy_memory(output_element, slice_ptr, min_offset_bytes);
                output_element += min_offset;

                loop_index[last_axis - 1] += 1;
                for (int i = last_axis - 1; i > 0; --i) {
                    if (loop_index[i] == loop_end[i]) {
                        loop_index[i] = loop_start[i];
                        loop_index[i - 1] += 1;
                    } else
                        break;
                }
            }
        }
    } else {
        if (dims == 1) {
            slice_ptr = input_element + input->get_element_index(loop_start);
            if (loop_step[0] == 1) {
                tool::copy_memory(output_element, slice_ptr, min_offset_bytes);
            } else {
                for (int i = 0; i < min_offset; i += loop_step[0]) {
                    *output_element = *slice_ptr;
                    slice_ptr += loop_step[0];
                    output_element += 1;
                }
            }
        } else if (last_axis == 0) {
            // Multi-dimensional tensor slicing the outermost axis (axis 0).
            // loop_step[0] is a coordinate-space step, NOT a flat-memory stride:
            // each selected coordinate yields a contiguous_block_size memory block.
            if (loop_step[0] == 1) {
                slice_ptr = input_element + input->get_element_index(loop_start);
                tool::copy_memory(output_element, slice_ptr, min_offset_bytes);
            } else {
                std::vector<int> loop_index = loop_start;
                for (int idx = loop_start[0]; idx < loop_end[0]; idx += loop_step[0]) {
                    loop_index[0] = idx;
                    slice_ptr = input_element + input->get_element_index(loop_index);
                    tool::copy_memory(output_element, slice_ptr, block_bytes);
                    output_element += contiguous_block_size;
                }
            }
        } else {
            std::vector<int> loop_index = loop_start;
            while (loop_index[0] < loop_end[0]) {
                if (loop_step[last_axis] == 1) {
                    slice_ptr = input_element + input->get_element_index(loop_index);
                    tool::copy_memory(output_element, slice_ptr, min_offset_bytes);
                    output_element += min_offset;
                } else {
                    for (int idx = loop_start[last_axis]; idx < loop_end[last_axis]; idx += loop_step[last_axis]) {
                        loop_index[last_axis] = idx;
                        slice_ptr = input_element + input->get_element_index(loop_index);
                        tool::copy_memory(output_element, slice_ptr, block_bytes);
                        output_element += contiguous_block_size;
                    }
                }

                loop_index[last_axis - 1] += loop_step[last_axis - 1];
                for (int i = last_axis - 1; i > 0; --i) {
                    if (loop_index[i] >= loop_end[i]) {
                        loop_index[i] = loop_start[i];
                        loop_index[i - 1] += loop_step[i - 1];
                    } else
                        break;
                }
            }
        }
    }

    if (!flipped.empty()) {
        _flip<T>(output, flipped);
    }
}

void TensorBase::slice(TensorBase *input,
                       TensorBase *output,
                       const std::vector<int> &start,
                       const std::vector<int> &end,
                       const std::vector<int> &axes,
                       const std::vector<int> &step)
{
    dtype_t dtype = input->get_dtype();
    assert(dtype == output->get_dtype());

    if (dtype == DATA_TYPE_INT8) {
        _slice<int8_t>(input, output, start, end, axes, step);
    } else if (dtype == DATA_TYPE_INT16) {
        _slice<int16_t>(input, output, start, end, axes, step);
    } else if (dtype == DATA_TYPE_FLOAT) {
        _slice<float>(input, output, start, end, axes, step);
    } else if (dtype == DATA_TYPE_UINT8) {
        _slice<uint8_t>(input, output, start, end, axes, step);
    } else if (dtype == DATA_TYPE_UINT16) {
        _slice<uint16_t>(input, output, start, end, axes, step);
    } else if (dtype == DATA_TYPE_INT32) {
        _slice<int32_t>(input, output, start, end, axes, step);
    } else if (dtype == DATA_TYPE_UINT32) {
        _slice<uint32_t>(input, output, start, end, axes, step);
    } else {
        ESP_LOGE(__FUNCTION__, "Unsupported data type");
    }
}

template <typename T>
TensorBase *TensorBase::pad(T *input_element,
                            const std::vector<int> &input_shape,
                            const std::vector<int> &pads,
                            const padding_mode_t mode,
                            TensorBase *const_value)
{
    T const_value_element = 0;
    if (const_value) {
        const_value_element = const_value->get_element<T>(0);
    }

    T *output_element = this->get_element_ptr<T>();
    int dims = input_shape.size();

    if (dims == 4) {
        base::pad4D<T>(input_element, output_element, input_shape, pads, mode, const_value_element);
    } else if (dims == 3) {
        base::pad3D<T>(input_element, output_element, input_shape, pads, mode, const_value_element);
    } else if (dims == 2) {
        base::pad2D<T>(input_element, output_element, input_shape, pads, mode, const_value_element);
    } else if (dims == 1) {
        base::pad1D<T>(input_element, output_element, input_shape, pads, mode, const_value_element);
    } else if (dims == 5 && mode != PADDING_CONSTANT) {
        if (pads[0] == 0 && pads[5] == 0) {
            std::vector<int> new_pads = {pads[1], pads[2], pads[3], pads[4], pads[6], pads[7], pads[8], pads[9]};
            std::vector<int> new_shape = {
                input_shape[0] * input_shape[1], input_shape[2], input_shape[3], input_shape[4]};
            base::pad4D<T>(input_element, output_element, new_shape, new_pads, mode, const_value_element);
        }
    } else if (dims > 4 && mode == PADDING_CONSTANT) {
        std::vector<int> loop_start(dims, 0);
        std::vector<int> loop_end(dims, 0);
        T *slice_ptr = nullptr;
        int last_axis = dims - 1;
        int min_offset = input_shape[last_axis];
        int min_offset_bytes = min_offset * sizeof(T);

        for (int i = 0; i < dims; i++) {
            loop_start[i] = pads[i];
            loop_end[i] = loop_start[i] + input_shape[i];
        }

        // step1: set value
        if (const_value_element == 0) {
            tool::set_zero(output_element, this->get_bytes());
        } else {
            tool::set_value<T>(output_element, const_value_element, this->get_size());
        }

        // step2: copy input into output, like slice op
        if (dims == 1) {
            slice_ptr = output_element + this->get_element_index(loop_start);
            tool::copy_memory(slice_ptr, input_element, min_offset_bytes);
        } else {
            std::vector<int> loop_index = loop_start;
            while (loop_index[0] < loop_end[0]) {
                slice_ptr = output_element + this->get_element_index(loop_index);
                tool::copy_memory(slice_ptr, input_element, min_offset_bytes);
                input_element += min_offset;

                loop_index[last_axis - 1] += 1;
                for (int i = last_axis - 1; i > 0; --i) {
                    if (loop_index[i] == loop_end[i]) {
                        loop_index[i] = loop_start[i];
                        loop_index[i - 1] += 1;
                    } else
                        break;
                }
            }
        }
    } else {
        ESP_LOGE("Pad", "Not implemented dim: %d", dims);
    }

    return this;
}
template TensorBase *TensorBase::pad(int8_t *input_element,
                                     const std::vector<int> &input_shape,
                                     const std::vector<int> &pads,
                                     const padding_mode_t mode,
                                     TensorBase *const_value);
template TensorBase *TensorBase::pad(uint8_t *input_element,
                                     const std::vector<int> &input_shape,
                                     const std::vector<int> &pads,
                                     const padding_mode_t mode,
                                     TensorBase *const_value);
template TensorBase *TensorBase::pad(int16_t *input_element,
                                     const std::vector<int> &input_shape,
                                     const std::vector<int> &pads,
                                     const padding_mode_t mode,
                                     TensorBase *const_value);
template TensorBase *TensorBase::pad(uint16_t *input_element,
                                     const std::vector<int> &input_shape,
                                     const std::vector<int> &pads,
                                     const padding_mode_t mode,
                                     TensorBase *const_value);
template TensorBase *TensorBase::pad(int32_t *input_element,
                                     const std::vector<int> &input_shape,
                                     const std::vector<int> &pads,
                                     const padding_mode_t mode,
                                     TensorBase *const_value);
template TensorBase *TensorBase::pad(uint32_t *input_element,
                                     const std::vector<int> &input_shape,
                                     const std::vector<int> &pads,
                                     const padding_mode_t mode,
                                     TensorBase *const_value);
template TensorBase *TensorBase::pad(float *input_element,
                                     const std::vector<int> &input_shape,
                                     const std::vector<int> &pads,
                                     const padding_mode_t mode,
                                     TensorBase *const_value);

TensorBase *TensorBase::pad(TensorBase *input,
                            const std::vector<int> &pads,
                            const padding_mode_t mode,
                            TensorBase *const_value)
{
    dtype_t dtype = this->get_dtype();
    assert(dtype == input->get_dtype());

    if (dtype == DATA_TYPE_INT8) {
        return this->pad<int8_t>(input->get_element_ptr<int8_t>(), input->get_shape(), pads, mode, const_value);
    } else if (dtype == DATA_TYPE_INT16) {
        return this->pad<int16_t>(input->get_element_ptr<int16_t>(), input->get_shape(), pads, mode, const_value);
    } else if (dtype == DATA_TYPE_FLOAT) {
        return this->pad<float>(input->get_element_ptr<float>(), input->get_shape(), pads, mode, const_value);
    } else if (dtype == DATA_TYPE_UINT8) {
        return this->pad<uint8_t>(input->get_element_ptr<uint8_t>(), input->get_shape(), pads, mode, const_value);
    } else if (dtype == DATA_TYPE_UINT16) {
        return this->pad<uint16_t>(input->get_element_ptr<uint16_t>(), input->get_shape(), pads, mode, const_value);
    } else if (dtype == DATA_TYPE_INT32) {
        return this->pad<int32_t>(input->get_element_ptr<int32_t>(), input->get_shape(), pads, mode, const_value);
    } else if (dtype == DATA_TYPE_UINT32) {
        return this->pad<uint32_t>(input->get_element_ptr<uint32_t>(), input->get_shape(), pads, mode, const_value);
    } else {
        ESP_LOGE(__FUNCTION__, "Unsupported data type");
    }

    return this;
}

void TensorBase::memset(int value)
{
    ::memset(this->data, value, this->get_bytes());
}

void TensorBase::rand()
{
    if (this->data) {
        esp_fill_random(this->data, this->get_bytes());
    }
}

} // namespace dl
